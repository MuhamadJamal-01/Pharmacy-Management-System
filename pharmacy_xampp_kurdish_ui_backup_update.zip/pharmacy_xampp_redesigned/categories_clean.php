<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin','manager']); ensure_real_pharmacy_schema($conn);
ensure_categories_table($conn);

$msg = '';
// load categories (from categories table if present, else from medicines)
$categories = [];
$hasCategoriesTable = false;
$cr = $conn->query("SHOW TABLES LIKE 'categories'");
if ($cr && $cr->num_rows>0) {
  $hasCategoriesTable = true;
  $res = $conn->query("SELECT id,name FROM categories ORDER BY name");
  while($r=$res->fetch_assoc()) $categories[$r['name']] = $r['id'];
} else {
  $res = $conn->query("SELECT DISTINCT category FROM medicines WHERE category IS NOT NULL AND category<>'' ORDER BY category");
  while($r=$res->fetch_assoc()) $categories[$r['category']] = null;
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
  verify_csrf();
  $target = trim($_POST['target'] ?? '');
  $sources = $_POST['source'] ?? [];
  $sources = array_values(array_filter($sources, function($source) use ($target) {
    return $source !== $target;
  }));
  if (!$target || empty($sources)) { $msg = t('select_target_source'); }
  else {
    // Update medicines
    $placeholders = implode(',', array_fill(0, count($sources), '?'));
    $types = str_repeat('s', count($sources));
    $stmt = $conn->prepare("UPDATE medicines SET category=? WHERE category IN ($placeholders)");
    $typesAll = 's' . $types;
    $bindValues = [$typesAll, $target];
    foreach ($sources as $source) { $bindValues[] = $source; }
    $refs = [];
    foreach ($bindValues as $key => $value) { $refs[$key] = &$bindValues[$key]; }
    call_user_func_array([$stmt, 'bind_param'], $refs);
    $stmt->execute();

    // If categories table exists, ensure target exists and delete source rows
    if ($hasCategoriesTable) {
      $stmt = $conn->prepare('INSERT IGNORE INTO categories (name) VALUES (?)'); $stmt->bind_param('s',$target); $stmt->execute();
      $place = implode(',', array_fill(0,count($sources),'?'));
      $stmt = $conn->prepare("DELETE FROM categories WHERE name IN ($place)");
      $types2 = str_repeat('s', count($sources));
      $bindValues2 = array_merge([$types2], $sources);
      $refs2 = [];
      foreach ($bindValues2 as $key => $value) { $refs2[$key] = &$bindValues2[$key]; }
      call_user_func_array([$stmt, 'bind_param'], $refs2);
      $stmt->execute();
    }
    $msg = 'Merged categories into "' . h($target) . '"';
    // reload categories
    header('Location: categories_clean.php'); exit;
  }
}

include 'includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title"><?= t('normalize_categories') ?></h1><p class="page-subtitle"><?= t('normalize_categories_subtitle') ?></p></div></div>
  <?php if($msg): ?><div class="alert ok"><?= h($msg) ?></div><?php endif; ?>
  <form method="POST" class="form-card">
    <?= csrf_field() ?>
    <div class="form-grid">
      <div>
        <label><?= t('target_category') ?></label>
        <select name="target" class="input" required>
          <option value="">-- Select target --</option>
          <?php foreach(array_keys($categories) as $c): ?><option value="<?= h($c) ?>"><?= h($c) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div>
        <label><?= t('source_categories') ?></label>
        <div style="max-height:220px;overflow:auto;border:1px solid #eee;padding:8px">
          <?php foreach(array_keys($categories) as $c): ?>
            <div><label><input type="checkbox" name="source[]" value="<?= h($c) ?>"> <?= h($c) ?></label></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <div style="margin-top:12px"><button class="btn" type="submit"><?= t('merge') ?></button> <a class="btn secondary" href="categories.php"><?= t('back') ?></a></div>
  </form>
</div>
<?php include 'includes/footer.php'; ?>
