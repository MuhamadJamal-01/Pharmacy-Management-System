<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin','manager']); ensure_real_pharmacy_schema($conn);
$id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare('SELECT p.*, s.name supplier_name, u.name user_name FROM purchases p LEFT JOIN suppliers s ON s.id=p.supplier_id LEFT JOIN users u ON u.id=p.user_id WHERE p.id=?');
$stmt->bind_param('i',$id); $stmt->execute(); $purchase = $stmt->get_result()->fetch_assoc(); $stmt->close();
if (!$purchase) redirect('purchases.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'return_item') {
    verify_csrf();
    $itemId = (int)($_POST['item_id'] ?? 0); $qty = max(1,(int)($_POST['quantity'] ?? 1));
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare('SELECT * FROM purchase_items WHERE id=? AND purchase_id=? FOR UPDATE');
        $stmt->bind_param('ii',$itemId,$id); $stmt->execute(); $item = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if (!$item) throw new RuntimeException('Item not found');
        $available = (int)$item['quantity'] - (int)$item['returned_quantity'];
        if ($qty > $available) throw new RuntimeException('Return quantity is too high');
        $stmt = $conn->prepare('UPDATE medicine_batches SET quantity=GREATEST(quantity-?,0) WHERE id=?');
        $stmt->bind_param('ii',$qty,$item['batch_id']); $stmt->execute(); $stmt->close();
        $stmt = $conn->prepare('UPDATE purchase_items SET returned_quantity=returned_quantity+? WHERE id=?');
        $stmt->bind_param('ii',$qty,$itemId); $stmt->execute(); $stmt->close();
        record_stock_movement($conn, (int)$item['medicine_id'], (int)$item['batch_id'], -$qty, 'purchase_return', 'Returned to supplier', 'purchases', $id);
        log_audit($conn, 'purchase_return', 'purchase_items', $itemId, $item, ['returned_qty'=>$qty]);
        $conn->commit(); redirect('purchase_view.php?id='.$id);
    } catch (Throwable $e) { $conn->rollback(); $error = $e->getMessage(); }
}
$items = $conn->query("SELECT pi.*, m.name medicine_name, b.batch_number FROM purchase_items pi JOIN medicines m ON m.id=pi.medicine_id LEFT JOIN medicine_batches b ON b.id=pi.batch_id WHERE pi.purchase_id=".(int)$id." ORDER BY pi.id");
include 'includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title">Purchase <?= h($purchase['invoice_number']) ?></h1><p class="page-subtitle"><?= h($purchase['supplier_name'] ?? '-') ?> · <?= h($purchase['purchase_date']) ?></p></div><a class="btn secondary" href="purchases.php">Back</a></div>
  <?php if(!empty($error)): ?><div class="alert bad"><?= h($error) ?></div><?php endif; ?>
  <div class="cards"><div class="card"><h3><?= t('total') ?></h3><p><?= money($purchase['total_amount']) ?></p></div><div class="card"><h3><?= t('status') ?></h3><p><?= h($purchase['status']) ?></p></div><div class="card"><h3><?= t('user') ?></h3><p><?= h($purchase['user_name'] ?? '-') ?></p></div></div>
  <div class="table-card"><div class="table-header"><h2><?= t('items_supplier_returns') ?></h2></div><div class="table-scroll"><table><thead><tr><th><?= t('name') ?></th><th><?= t('batch_number') ?></th><th><?= t('quantity') ?></th><th><?= t('returned') ?></th><th><?= t('purchase_price') ?></th><th><?= t('selling_price') ?></th><th><?= t('actions') ?></th></tr></thead><tbody>
  <?php while($it=$items->fetch_assoc()): $remaining=(int)$it['quantity']-(int)$it['returned_quantity']; ?>
    <tr><td><?= h($it['medicine_name']) ?></td><td class="mono"><?= h($it['batch_number']) ?></td><td><?= (int)$it['quantity'] ?></td><td><?= (int)$it['returned_quantity'] ?></td><td><?= money($it['purchase_price']) ?></td><td><?= money($it['selling_price']) ?></td><td><?php if($remaining>0): ?><form method="POST" class="toolbar"><?= csrf_field() ?><input type="hidden" name="action" value="return_item"><input type="hidden" name="item_id" value="<?= (int)$it['id'] ?>"><input class="input" style="width:90px" type="number" name="quantity" min="1" max="<?= $remaining ?>" value="1"><button class="btn danger" onclick="return confirm('Return this quantity to supplier?')">Return</button></form><?php else: ?><span class="badge bad">Returned</span><?php endif; ?></td></tr>
  <?php endwhile; ?>
  </tbody></table></div></div>
</div>
<?php include 'includes/footer.php'; ?>
