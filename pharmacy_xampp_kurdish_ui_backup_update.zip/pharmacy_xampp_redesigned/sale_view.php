<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin','manager','pharmacist','cashier']); ensure_real_pharmacy_schema($conn);
$id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare('SELECT s.*, u.name user_name, p.patient_name, p.prescription_number FROM sales s LEFT JOIN users u ON u.id=s.user_id LEFT JOIN prescriptions p ON p.id=s.prescription_id WHERE s.id=?');
$stmt->bind_param('i',$id); $stmt->execute(); $sale = $stmt->get_result()->fetch_assoc(); $stmt->close();
if (!$sale) redirect('sales.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'refund_item') {
  verify_csrf();
  if (!has_role(['admin','manager','pharmacist'])) { http_response_code(403); exit('Access denied'); }
  $itemId = (int)($_POST['item_id'] ?? 0); $qty = max(1,(int)($_POST['quantity'] ?? 1));
  $conn->begin_transaction();
  try {
    $stmt=$conn->prepare('SELECT * FROM sale_items WHERE id=? AND sale_id=? FOR UPDATE'); $stmt->bind_param('ii',$itemId,$id); $stmt->execute(); $item=$stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$item) throw new RuntimeException('Item not found');
    $available=(int)$item['quantity']-(int)$item['refunded_quantity'];
    if ($qty>$available) throw new RuntimeException('Refund quantity is too high');
    $stmt=$conn->prepare('UPDATE sale_items SET refunded_quantity=refunded_quantity+? WHERE id=?'); $stmt->bind_param('ii',$qty,$itemId); $stmt->execute(); $stmt->close();
    $stmt=$conn->prepare('UPDATE medicine_batches SET quantity=quantity+? WHERE id=?'); $stmt->bind_param('ii',$qty,$item['batch_id']); $stmt->execute(); $stmt->close();
    record_stock_movement($conn, (int)$item['medicine_id'], (int)$item['batch_id'], $qty, 'refund', 'Customer sale refund', 'sales', $id);
    log_audit($conn, 'sale_refund', 'sale_items', $itemId, $item, ['refunded_qty'=>$qty]);
    $remain=$conn->query('SELECT SUM(quantity-refunded_quantity) remain FROM sale_items WHERE sale_id='.(int)$id)->fetch_assoc()['remain'];
    if ((int)$remain <= 0) $conn->query("UPDATE sales SET status='refunded' WHERE id=".(int)$id);
    $conn->commit(); redirect('sale_view.php?id='.$id);
  } catch (Throwable $e) { $conn->rollback(); $error=$e->getMessage(); }
}
$items = $conn->query("SELECT si.*, m.name medicine_name, b.batch_number FROM sale_items si JOIN medicines m ON m.id=si.medicine_id LEFT JOIN medicine_batches b ON b.id=si.batch_id WHERE si.sale_id=".(int)$id." ORDER BY si.id");
include 'includes/header.php';
?>
<div class="content">
  <div class="page-head no-print"><div><h1 class="page-title"><?= t('receipt') ?> <?= h($sale['invoice_number']) ?></h1><p class="page-subtitle"><?= h($sale['created_at']) ?></p></div><div class="actions-row"><button class="btn" onclick="window.print()"><span class="material-symbols-outlined">print</span>Print Receipt</button><a class="btn secondary" href="sales.php">Back</a></div></div>
  <?php if(!empty($error)): ?><div class="alert bad no-print"><?= h($error) ?></div><?php endif; ?>
  <section class="form-card" style="max-width:760px;margin:auto">
    <div style="text-align:center"><h1>PharmaFlow</h1><p class="muted"><?= t('pharmacy_sale_receipt') ?></p></div>
    <div class="split-grid" style="grid-template-columns:1fr 1fr"><div><strong><?= t('invoice') ?>:</strong> <?= h($sale['invoice_number']) ?><br><strong><?= t('date') ?>:</strong> <?= h($sale['created_at']) ?><br><strong><?= t('cashier') ?>:</strong> <?= h($sale['user_name'] ?? '-') ?></div><div><strong>Payment:</strong> <?= h(ucfirst($sale['payment_method'] ?? 'cash')) ?><br><strong>Patient/Rx:</strong> <?= h($sale['patient_name'] ?? '-') ?> <?= $sale['prescription_number'] ? ' / '.h($sale['prescription_number']) : '' ?><br><strong>Status:</strong> <?= h($sale['status'] ?? 'completed') ?></div></div>
    <div class="table-scroll" style="margin-top:20px"><table><thead><tr><th><?= t('name') ?></th><th><?= t('batch_number') ?></th><th><?= t('quantity') ?></th><th><?= t('refunded') ?></th><th><?= t('selling_price') ?></th><th><?= t('total') ?></th><th class="no-print">Refund</th></tr></thead><tbody>
    <?php while($it=$items->fetch_assoc()): $remaining=(int)$it['quantity']-(int)$it['refunded_quantity']; ?>
      <tr><td><?= h($it['medicine_name']) ?></td><td class="mono"><?= h($it['batch_number']) ?></td><td><?= (int)$it['quantity'] ?></td><td><?= (int)$it['refunded_quantity'] ?></td><td><?= money($it['price']) ?></td><td><?= money($it['total']) ?></td><td class="no-print"><?php if($remaining>0 && has_role(['admin','manager','pharmacist'])): ?><form method="POST" class="toolbar"><?= csrf_field() ?><input type="hidden" name="action" value="refund_item"><input type="hidden" name="item_id" value="<?= (int)$it['id'] ?>"><input class="input" style="width:80px" name="quantity" type="number" min="1" max="<?= $remaining ?>" value="1"><button class="btn danger" onclick="return confirm('Refund this item quantity?')">Refund</button></form><?php else: ?>-<?php endif; ?></td></tr>
    <?php endwhile; ?>
    </tbody></table></div>
    <div style="text-align:right;margin-top:18px"><p><?= t('discount') ?>: <strong><?= money($sale['discount_amount'] ?? 0) ?></strong></p><h2><?= t('total') ?>: <?= money($sale['total_amount']) ?></h2></div>
  </section>
</div>
<style>@media print{.sidebar,.topbar,.no-print{display:none!important}.main{margin:0!important;width:100%!important}.content{padding:0!important}.form-card{box-shadow:none;border:0}}</style>
<?php include 'includes/footer.php'; ?>
