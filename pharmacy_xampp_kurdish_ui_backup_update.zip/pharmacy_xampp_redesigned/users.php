<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin']); ensure_real_pharmacy_schema($conn);
$message=''; $messageClass='ok';
$roles = ['admin','manager','pharmacist','cashier'];
if ($_SERVER['REQUEST_METHOD']==='POST') {
  verify_csrf(); $action=$_POST['action'] ?? 'create';
  if ($action==='create') {
    $name=trim($_POST['name'] ?? ''); $email=trim($_POST['email'] ?? ''); $role=$_POST['role'] ?? 'cashier'; $password=$_POST['password'] ?? '';
    if ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || !in_array($role,$roles,true) || strlen($password)<8) { $message=t('valid_user_password'); $messageClass='bad'; }
    else { try { $hash=password_hash($password,PASSWORD_DEFAULT); $stmt=$conn->prepare('INSERT INTO users(name,email,password_hash,role,is_active) VALUES(?,?,?,?,1)'); $stmt->bind_param('ssss',$name,$email,$hash,$role); $stmt->execute(); $id=$conn->insert_id; $stmt->close(); log_audit($conn,'create_user','users',$id,null,get_row_by_id($conn,'users',$id)); $message=t('user_created'); } catch(Throwable $e){ $message='Could not create user. Email may already exist.'; $messageClass='bad'; } }
  } elseif ($action==='toggle') {
    $id=(int)($_POST['id'] ?? 0); if ($id !== (int)$_SESSION['user_id']) { $old=get_row_by_id($conn,'users',$id); $stmt=$conn->prepare('UPDATE users SET is_active=IF(is_active=1,0,1) WHERE id=?'); $stmt->bind_param('i',$id); $stmt->execute(); $stmt->close(); log_audit($conn,'toggle_user_active','users',$id,$old,get_row_by_id($conn,'users',$id)); }
  } elseif ($action==='delete') {
    $id=(int)($_POST['id'] ?? 0); if ($id !== (int)$_SESSION['user_id']) { $old=get_row_by_id($conn,'users',$id); $stmt=$conn->prepare('UPDATE users SET deleted_at=NOW(), is_active=0 WHERE id=?'); $stmt->bind_param('i',$id); $stmt->execute(); $stmt->close(); log_audit($conn,'soft_delete_user','users',$id,$old,null); }
  }
}
$rows=$conn->query('SELECT id,name,email,role,is_active,last_login_at,created_at FROM users WHERE deleted_at IS NULL ORDER BY role,name');
include 'includes/header.php';
?>
<div class="content">
 <div class="page-head"><div><h1 class="page-title"><?= t('users') ?></h1><p class="page-subtitle"><?= t('users_subtitle') ?></p></div></div>
 <?php if($message): ?><div class="alert <?= h($messageClass) ?>"><?= h($message) ?></div><?php endif; ?>
 <div class="split-grid"><form class="form-card" method="POST"><?= csrf_field() ?><input type="hidden" name="action" value="create"><h2 class="section-title" style="margin-top:0"><?= t('create_user') ?></h2><div class="form-grid"><div><label><?= t('name') ?></label><input class="input" name="name" required></div><div><label><?= t('email') ?></label><input class="input" type="email" name="email" required></div><div><label><?= t('role') ?></label><select class="input" name="role"><?php foreach($roles as $r): ?><option value="<?= h($r) ?>"><?= h(ucfirst($r)) ?></option><?php endforeach; ?></select></div><div><label><?= t('password') ?></label><input class="input" type="password" name="password" minlength="8" required></div></div><br><button class="btn">Create User</button></form><div class="card"><h3>Role Rules</h3><p style="font-size:16px;letter-spacing:0">Cashier: POS only<br>Pharmacist: POS, prescriptions, reports, stock adjustments<br>Manager: inventory, purchases, reports<br>Admin: full access</p></div></div>
 <br><div class="table-card"><div class="table-header"><h2><?= t('users') ?></h2></div><div class="table-scroll"><table><thead><tr><th><?= t('name') ?></th><th><?= t('email') ?></th><th><?= t('role') ?></th><th><?= t('active') ?></th><th><?= t('last_login') ?></th><th><?= t('actions') ?></th></tr></thead><tbody><?php while($u=$rows->fetch_assoc()): ?><tr><td><?= h($u['name']) ?></td><td><?= h($u['email']) ?></td><td><span class="badge ok"><?= h($u['role']) ?></span></td><td><?= (int)$u['is_active'] ? 'Yes' : 'No' ?></td><td><?= h($u['last_login_at'] ?? '-') ?></td><td><div class="toolbar"><?php if((int)$u['id'] !== (int)$_SESSION['user_id']): ?><form method="POST"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="btn secondary" type="submit"><?= (int)$u['is_active'] ? 'Deactivate' : 'Activate' ?></button></form><form method="POST" onsubmit="return confirm('Delete this user?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="btn danger" type="submit">Delete</button></form><?php endif; ?></div></td></tr><?php endwhile; ?></tbody></table></div></div>
</div>
<?php include 'includes/footer.php'; ?>
