# ڕێنمایی بەکارهێنانی ڕاستەقینە و پاراستنی داتا

ئەم فێرژنە باشتر کراوە بۆ کوردی، responsive UI، scroll، و backup script. بەڵام پێش بەکارهێنانی دەرمانخانەی ڕاستەقینە ئەمانە لەسەر تۆیە:

## 1) تاقیکردنەوەی هەموو لاپەڕەکان
- Login
- Dashboard
- Medicines
- POS
- Sales و receipt
- Purchases
- Prescriptions
- Users
- Stock adjustments
- Reports
- Backup / Restore

## 2) Backup ـی خۆکار لە Mac XAMPP
فایلەکە:

```bash
scripts/backup_database_mac_xampp.sh
```

تاقیکردنەوە:

```bash
/Applications/XAMPP/xamppfiles/htdocs/pharmacy_xampp_redesigned/scripts/backup_database_mac_xampp.sh
```

Backup لێرە دروست دەبێت:

```text
/Users/Shared/pharmacy_backups
```

بۆ خۆکارکردن هەموو شەوێک کاتژمێر 11:

```bash
crontab -e
```

ئەم دێڕە زیاد بکە:

```bash
0 23 * * * /Applications/XAMPP/xamppfiles/htdocs/pharmacy_xampp_redesigned/scripts/backup_database_mac_xampp.sh
```

## 3) Restore تاقی بکەوە
تەنها backup هەبوون بەس نییە. جارێک لەسەر database ـی test هەوڵ بدە backup بگەڕێنیتەوە.

## 4) بۆ بەکارهێنانی بێ XAMPP
بۆ کەسی ئاسایی باشترین ڕێگا ئەوەیە کە Apache/PHP/MariaDB وەک service دابنرێن و shortcut بکەیت بۆ:

```text
http://localhost/pharmacy_xampp_redesigned/
```

یا دواتر installer بۆ Windows/Mac دروست بکەیت. ئەمە هێشتا لەم ZIP ـەدا installer نییە.

## 5) شتانی پێویست پێش real-life
- Security audit لەلایەن کەسی شارەزا
- تاقیکردنەوەی receipt printer
- تاقیکردنەوەی barcode scanner
- UPS بۆ server
- External/cloud backup
- ڕێنمایی یاسایی دەرمانخانەی ناوخۆ
