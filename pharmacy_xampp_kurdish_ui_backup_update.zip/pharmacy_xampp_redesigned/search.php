<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin','manager','pharmacist','cashier']); ensure_real_pharmacy_schema($conn);
$q = trim($_GET['q'] ?? '');
include 'includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title"><?= t('search_results') ?></h1><p class="page-subtitle"><?= h($q ?: t('global_search')) ?></p></div></div>
  <?php if ($q === ''): ?>
    <div class="card"><div class="content"><?= t('enter_search_term') ?></div></div>
  <?php else: ?>
    <div class="cards">
      <div class="card">
        <h3><?= t('medicines') ?></h3>
        <div class="mini muted"><?= t('matching_medicines') ?></div>
        <div style="margin-top:12px">
          <ul>
            <?php
            $stmt = $conn->prepare("SELECT id,name,generic_name FROM medicines WHERE deleted_at IS NULL AND (name LIKE ? OR generic_name LIKE ?) LIMIT 20");
            $like = "%" . $q . "%";
            $stmt->bind_param('ss',$like,$like);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($r = $res->fetch_assoc()) {
                echo '<li><a href="medicine_view.php?id=' . (int)$r['id'] . '">' . h($r['name']) . ' <span class="muted">' . h($r['generic_name']) . '</span></a></li>';
            }
            $stmt->close();
            ?>
          </ul>
        </div>
      </div>
      <div class="card">
        <h3><?= t('suppliers') ?></h3>
        <div class="mini muted"><?= t('matching_suppliers') ?></div>
        <div style="margin-top:12px">
          <ul>
            <?php
            $stmt = $conn->prepare("SELECT id,name FROM suppliers WHERE deleted_at IS NULL AND name LIKE ? LIMIT 20");
            $stmt->bind_param('s',$like);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($r = $res->fetch_assoc()) {
                echo '<li><a href="suppliers.php?id=' . (int)$r['id'] . '">' . h($r['name']) . '</a></li>';
            }
            $stmt->close();
            ?>
          </ul>
        </div>
      </div>
      <div class="card">
        <h3><?= t('sales_invoices') ?></h3>
        <div class="mini muted"><?= t('search_invoices_by_number') ?></div>
        <div style="margin-top:12px">
          <ul>
            <?php
            $stmt = $conn->prepare("SELECT id,invoice_number,created_at FROM sales WHERE invoice_number LIKE ? LIMIT 20");
            $stmt->bind_param('s',$like);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($r = $res->fetch_assoc()) {
                echo '<li><a href="sale_view.php?id=' . (int)$r['id'] . '">' . h($r['invoice_number']) . ' <span class="muted">' . h($r['created_at']) . '</span></a></li>';
            }
            $stmt->close();
            ?>
          </ul>
        </div>
      </div>
    </div>
  <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>
