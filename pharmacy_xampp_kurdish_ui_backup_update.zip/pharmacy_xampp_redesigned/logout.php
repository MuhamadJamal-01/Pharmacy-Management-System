<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
ensure_real_pharmacy_schema($conn);
if (!empty($_SESSION['user_id'])) log_audit($conn, 'logout', 'users', (int)$_SESSION['user_id']);
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
}
session_destroy();
redirect('index.php');
?>
