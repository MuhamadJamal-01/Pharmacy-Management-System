# PharmaFlow XAMPP Pharmacy System - Real Pharmacy Upgrade

This build keeps the original XAMPP PHP/MySQL style and Kurdish/RTL UI, but adds stronger security and real-life pharmacy workflow features.

## New in this upgraded ZIP

- CSRF protection on sensitive forms/actions.
- Delete actions changed from GET links to POST forms.
- Default credentials removed from the login form.
- `debug_session.php` removed.
- Safer PHP error handling with logs in `storage/logs/php_errors.log`.
- Session regeneration after login and secure logout.
- Role-based access control:
  - Admin: full access.
  - Manager: inventory, suppliers, categories, purchases, reports, audit.
  - Pharmacist: POS, prescriptions, medicines, reports, stock adjustments.
  - Cashier: POS and sales/receipt access only.
- Admin user management page.
- Change-password page in Settings.
- Prescription module with patient record, upload, approval/rejection, and POS approval selection.
- Prescription-required flag for medicines.
- POS blocks cashier sale of prescription-required medicine unless an approved prescription is selected.
- IQD currency display.
- POS payment methods: cash, card, debt/credit.
- Discount support.
- Printable sale receipt page.
- Sale refund workflow that returns stock and logs movement.
- Purchase return workflow that removes stock and logs movement.
- Stock adjustments page with required reason.
- `stock_movements` table for purchase, sale, refund, adjustment, expired removal, supplier return, and manual correction.
- `audit_logs` table for logins, edits, purchases, sales, refunds, stock changes, user changes, and backups.
- Admin backup/restore page.
- Improved reports: sales, profit, low stock, expiry, stock movement, supplier purchases, user activity.
- Soft delete for users, medicines, suppliers, and categories.
- Indexes for barcode, batches, sales, purchases, stock movements, and audit logs.

## Run with XAMPP

1. Copy this folder to:

```text
/Applications/XAMPP/htdocs/pharmacy_xampp
```

or on Windows:

```text
C:\xampp\htdocs\pharmacy_xampp
```

2. Start Apache and MySQL from XAMPP.

3. For a fresh install, open phpMyAdmin and import:

```text
sql/pharmacy_db.sql
```

4. For an existing database from the older project, import:

```text
sql/upgrade_real_pharmacy.sql
```

The app also runs safe schema checks automatically when pages load, but importing the migration is still recommended.

5. Open:

```text
http://localhost/pharmacy_xampp
```

## Default demo login

```text
Email: admin@pharmacy.local
Password: admin123
```

Change this password immediately from **Settings → Change Password** before using real data.

## Important production notes

This is still a plain XAMPP PHP/MySQL project. Before using in a real pharmacy, you should also add HTTPS, tested automatic off-computer backups, local legal/compliance review, and stronger infrastructure controls. For controlled medicines and patient data, confirm local legal requirements first.

## Manual testing checklist

- Login as admin.
- Change admin password.
- Create manager/pharmacist/cashier users.
- Confirm cashier cannot open medicines, purchases, reports, users, backup, or audit logs.
- Add a medicine and mark one as prescription-required.
- Add a supplier purchase and check stock movement appears.
- Create and approve a prescription.
- Sell an OTC medicine through POS.
- Sell an Rx medicine as cashier with an approved prescription.
- Try selling an Rx medicine as cashier without a prescription and confirm it is blocked.
- Print a receipt from sales.
- Refund a sale item and confirm stock returns.
- Return a purchase item and confirm stock decreases.
- Create a stock adjustment with a reason.
- Open reports and audit logs.
- Download a database backup.

## Final Kurdish/UI update

This version adds:
- Kurdish Sorani as the default interface language.
- More translated menu/page/table/form labels.
- Responsive CSS patch to prevent hidden bottom content and improve laptop/mobile layouts.
- Mac XAMPP backup script: `scripts/backup_database_mac_xampp.sh`.
- Kurdish real-use guide: `docs/README_KU_REAL_USE.md`.

Before real-life use, test all pages, configure automatic backups, test restore, and review security/permissions.
