-- PharmaFlow real-pharmacy upgrade migration
-- Run once after importing the original database. The PHP app also runs safe schema checks automatically.
USE pharmacy_db;

CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL UNIQUE,
  deleted_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS last_login_at DATETIME NULL,
  ADD COLUMN IF NOT EXISTS deleted_at DATETIME NULL;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS deleted_at DATETIME NULL;
ALTER TABLE categories ADD COLUMN IF NOT EXISTS deleted_at DATETIME NULL;
ALTER TABLE medicines
  ADD COLUMN IF NOT EXISTS category_id INT NULL,
  ADD COLUMN IF NOT EXISTS requires_prescription TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS unit_name VARCHAR(50) NOT NULL DEFAULT 'unit',
  ADD COLUMN IF NOT EXISTS deleted_at DATETIME NULL;
ALTER TABLE medicine_batches ADD COLUMN IF NOT EXISTS deleted_at DATETIME NULL;
ALTER TABLE sales
  ADD COLUMN IF NOT EXISTS patient_id INT NULL,
  ADD COLUMN IF NOT EXISTS prescription_id INT NULL,
  ADD COLUMN IF NOT EXISTS payment_method ENUM('cash','card','debt') NOT NULL DEFAULT 'cash',
  ADD COLUMN IF NOT EXISTS discount_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS status ENUM('completed','refunded','void') NOT NULL DEFAULT 'completed';
ALTER TABLE sale_items ADD COLUMN IF NOT EXISTS refunded_quantity INT NOT NULL DEFAULT 0;
ALTER TABLE purchase_items ADD COLUMN IF NOT EXISTS returned_quantity INT NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS patients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(180) NOT NULL,
  phone VARCHAR(80),
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS prescriptions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NULL,
  patient_name VARCHAR(180) NOT NULL,
  doctor_name VARCHAR(180),
  prescription_number VARCHAR(120),
  image_path VARCHAR(255),
  status ENUM('pending','approved','rejected','used') NOT NULL DEFAULT 'pending',
  approved_by INT NULL,
  approved_at DATETIME NULL,
  notes TEXT,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_prescriptions_status (status),
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE SET NULL,
  FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS stock_movements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  medicine_id INT NOT NULL,
  batch_id INT NULL,
  quantity_change INT NOT NULL,
  movement_type ENUM('purchase','sale','refund','adjustment','expired_removal','purchase_return','manual_correction') NOT NULL,
  reason VARCHAR(255),
  reference_table VARCHAR(80),
  reference_id INT NULL,
  user_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_stock_movements_medicine_id (medicine_id),
  INDEX idx_stock_movements_created_at (created_at),
  FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE,
  FOREIGN KEY (batch_id) REFERENCES medicine_batches(id) ON DELETE SET NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audit_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  action VARCHAR(120) NOT NULL,
  table_name VARCHAR(120),
  record_id INT NULL,
  old_value JSON NULL,
  new_value JSON NULL,
  ip_address VARCHAR(64),
  user_agent VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_logs_user_id (user_id),
  INDEX idx_audit_logs_created_at (created_at),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS stock_adjustments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  medicine_id INT NOT NULL,
  batch_id INT NOT NULL,
  quantity_change INT NOT NULL,
  reason VARCHAR(255) NOT NULL,
  user_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE,
  FOREIGN KEY (batch_id) REFERENCES medicine_batches(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX IF NOT EXISTS idx_medicines_barcode ON medicines(barcode);
CREATE INDEX IF NOT EXISTS idx_medicines_category_id ON medicines(category_id);
CREATE INDEX IF NOT EXISTS idx_batches_medicine_id ON medicine_batches(medicine_id);
CREATE INDEX IF NOT EXISTS idx_batches_expiry_date ON medicine_batches(expiry_date);
CREATE INDEX IF NOT EXISTS idx_sales_created_at ON sales(created_at);
CREATE INDEX IF NOT EXISTS idx_purchases_created_at ON purchases(created_at);

INSERT IGNORE INTO categories(name) VALUES
('Antibiotics'),('Analgesics'),('Cardiovascular'),('Allergy'),('Stomach'),('Pain Relief'),('Vitamins'),('Dermatology'),('Respiratory');
