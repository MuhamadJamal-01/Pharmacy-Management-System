-- Migration: add categories table
CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Optional seed values
INSERT IGNORE INTO categories (name) VALUES
('Antibiotics'),('Analgesics'),('Cardiovascular'),('Allergy'),('Stomach'),('Pain Relief'),('Vitamins'),('Dermatology'),('Respiratory');
