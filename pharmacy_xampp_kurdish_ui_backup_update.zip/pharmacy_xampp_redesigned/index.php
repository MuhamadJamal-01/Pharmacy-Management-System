<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
ensure_real_pharmacy_schema($conn);
if (isset($_SESSION['user_id'])) { redirect('dashboard.php'); }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $conn->prepare('SELECT id, name, password_hash, role FROM users WHERE email=? AND is_active=1 AND deleted_at IS NULL LIMIT 1');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_role'] = $user['role'];
        $stmt = $conn->prepare('UPDATE users SET last_login_at=NOW() WHERE id=?');
        $stmt->bind_param('i', $_SESSION['user_id']); $stmt->execute(); $stmt->close();
        log_audit($conn, 'login', 'users', $_SESSION['user_id']);
        redirect('dashboard.php');
    } else {
        log_audit($conn, 'failed_login', 'users', null, null, ['email'=>$email]);
        $error = t('invalid_login');
    }
}
?>
<!DOCTYPE html>
<html lang="<?= current_lang() ?>" dir="<?= is_rtl() ? 'rtl' : 'ltr' ?>" class="dark">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= t('login') ?> - PharmaFlow</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Sans+Arabic:wght@400;600;700&family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page <?= is_rtl() ? 'rtl' : '' ?>">
<form class="login-card" method="POST" autocomplete="off">
  <?= csrf_field() ?>
  <div class="brand-mark"><span class="material-symbols-outlined" style="font-size:34px">medication</span></div>
  <h1>PharmaFlow</h1>
  <p class="page-subtitle"><?= t('clinical_precision') ?></p>
  <?php if($error): ?><div class="alert bad"><?= h($error) ?></div><?php endif; ?>
  <label><?= t('email') ?></label><input class="input" name="email" type="email" value="" placeholder="admin@example.com" required><br><br>
  <label><?= t('password') ?></label><input class="input" name="password" type="password" value="" required><br><br>
  <button class="btn" style="width:100%" type="submit"><span class="material-symbols-outlined">login</span><?= t('login') ?></button>
  <p class="muted" style="font-size:12px;text-align:center;margin-top:14px"><?= t('default_credentials_hidden') ?></p>
  <p style="text-align:center"><a class="language-pill" href="?lang=en">English</a> <a class="language-pill" href="?lang=ku">کوردی سۆرانی</a></p>
</form>
</body>
</html>
