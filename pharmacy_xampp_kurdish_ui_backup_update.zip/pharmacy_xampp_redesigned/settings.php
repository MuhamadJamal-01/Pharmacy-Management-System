<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
require_role(['admin','manager','pharmacist','cashier']); ensure_real_pharmacy_schema($conn);

$message = ''; $messageClass = 'ok';
$userId = (int)$_SESSION['user_id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  verify_csrf();
  $action = $_POST['action'] ?? 'profile';
  if ($action === 'profile') {
    $name = trim($_POST['name'] ?? ''); $email = trim($_POST['email'] ?? '');
    if ($name !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $old = get_row_by_id($conn, 'users', $userId);
      $stmt = $conn->prepare('UPDATE users SET name=?, email=? WHERE id=?');
      $stmt->bind_param('ssi', $name, $email, $userId); $stmt->execute(); $stmt->close();
      $_SESSION['user_name'] = $name;
      log_audit($conn, 'update_own_profile', 'users', $userId, $old, get_row_by_id($conn, 'users', $userId));
      $message = t('settings_saved');
    } else { $message = t('valid_name_email'); $messageClass='bad'; }
  } elseif ($action === 'password') {
    $current = $_POST['current_password'] ?? ''; $new = $_POST['new_password'] ?? ''; $confirm = $_POST['confirm_password'] ?? '';
    $stmt = $conn->prepare('SELECT password_hash FROM users WHERE id=?'); $stmt->bind_param('i',$userId); $stmt->execute(); $row=$stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$row || !password_verify($current, $row['password_hash'])) { $message=t('current_password_incorrect'); $messageClass='bad'; }
    elseif (strlen($new) < 8) { $message=t('password_min_8'); $messageClass='bad'; }
    elseif ($new !== $confirm) { $message=t('password_confirmation_mismatch'); $messageClass='bad'; }
    else { $hash=password_hash($new, PASSWORD_DEFAULT); $stmt=$conn->prepare('UPDATE users SET password_hash=? WHERE id=?'); $stmt->bind_param('si',$hash,$userId); $stmt->execute(); $stmt->close(); log_audit($conn,'change_own_password','users',$userId); $message='Password changed.'; }
  }
}
$stmt = $conn->prepare('SELECT name,email,role,created_at,last_login_at FROM users WHERE id=?');
$stmt->bind_param('i', $userId); $stmt->execute(); $user = $stmt->get_result()->fetch_assoc(); $stmt->close();
include 'includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title"><?= t('settings') ?></h1><p class="page-subtitle"><?= t('settings_subtitle') ?></p></div></div>
  <?php if($message): ?><div class="alert <?= h($messageClass) ?>"><?= h($message) ?></div><?php endif; ?>
  <div class="split-grid">
    <div>
      <form class="form-card" method="POST"><?= csrf_field() ?><input type="hidden" name="action" value="profile"><h2 class="section-title" style="margin-top:0"><?= t('account') ?></h2><div class="form-grid"><div><label><?= t('name') ?></label><input class="input" name="name" value="<?= h($user['name'] ?? '') ?>" required></div><div><label><?= t('email') ?></label><input class="input" type="email" name="email" value="<?= h($user['email'] ?? '') ?>" required></div></div><div class="actions-row" style="margin-top:22px"><button class="btn" type="submit"><span class="material-symbols-outlined">save</span><?= t('save') ?></button></div></form>
      <form class="form-card" method="POST" style="margin-top:18px"><?= csrf_field() ?><input type="hidden" name="action" value="password"><h2 class="section-title" style="margin-top:0"><?= t('change_password') ?></h2><div class="form-grid"><div><label>Current password</label><input class="input" type="password" name="current_password" required></div><div><label>New password</label><input class="input" type="password" name="new_password" minlength="8" required></div><div><label>Confirm new password</label><input class="input" type="password" name="confirm_password" minlength="8" required></div></div><div class="actions-row" style="margin-top:22px"><button class="btn" type="submit">Change Password</button></div></form>
    </div>
    <aside class="card quick-stat"><h3><?= t('session') ?></h3><p><?= h(ucfirst($user['role'] ?? 'user')) ?></p><div><?= t('signed_in_as') ?> <?= h($user['name'] ?? $_SESSION['user_name'] ?? 'User') ?></div><div class="stat-line"><span><?= t('language') ?></span><strong><?= strtoupper(current_lang()) ?></strong></div><div class="stat-line"><span>Created</span><strong><?= h(substr($user['created_at'] ?? '-', 0, 10)) ?></strong></div><div class="stat-line"><span>Last login</span><strong><?= h(substr($user['last_login_at'] ?? '-', 0, 16)) ?></strong></div></aside>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
