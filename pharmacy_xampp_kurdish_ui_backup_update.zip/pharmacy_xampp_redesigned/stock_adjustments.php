<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin','manager','pharmacist']); ensure_real_pharmacy_schema($conn);
$message=''; $messageClass='ok';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  verify_csrf();
  $batchId=(int)($_POST['batch_id'] ?? 0); $qty=(int)($_POST['quantity_change'] ?? 0); $reason=trim($_POST['reason'] ?? ''); $type=$_POST['movement_type'] ?? 'adjustment';
  if (!in_array($type,['adjustment','expired_removal','manual_correction'],true)) $type='adjustment';
  if ($batchId<=0 || $qty===0 || $reason==='') { $message=t('stock_adjustment_required'); $messageClass='bad'; }
  else {
    $conn->begin_transaction();
    try {
      $stmt=$conn->prepare('SELECT b.*, m.name medicine_name FROM medicine_batches b JOIN medicines m ON m.id=b.medicine_id WHERE b.id=? FOR UPDATE'); $stmt->bind_param('i',$batchId); $stmt->execute(); $batch=$stmt->get_result()->fetch_assoc(); $stmt->close();
      if (!$batch) throw new RuntimeException('Batch not found');
      $newQty=(int)$batch['quantity'] + $qty; if ($newQty < 0) throw new RuntimeException('Adjustment would make stock negative.');
      $stmt=$conn->prepare('UPDATE medicine_batches SET quantity=? WHERE id=?'); $stmt->bind_param('ii',$newQty,$batchId); $stmt->execute(); $stmt->close();
      $uid=(int)$_SESSION['user_id']; $mid=(int)$batch['medicine_id'];
      $stmt=$conn->prepare('INSERT INTO stock_adjustments(medicine_id,batch_id,quantity_change,reason,user_id) VALUES(?,?,?,?,?)'); $stmt->bind_param('iiisi',$mid,$batchId,$qty,$reason,$uid); $stmt->execute(); $adjId=$conn->insert_id; $stmt->close();
      record_stock_movement($conn,$mid,$batchId,$qty,$type,$reason,'stock_adjustments',$adjId);
      log_audit($conn,'stock_adjustment','medicine_batches',$batchId,$batch,['new_quantity'=>$newQty,'change'=>$qty,'reason'=>$reason]);
      $conn->commit(); $message=t('stock_adjustment_saved');
    } catch(Throwable $e){ $conn->rollback(); $message=$e->getMessage(); $messageClass='bad'; }
  }
}
$batches=$conn->query("SELECT b.id, b.batch_number, b.expiry_date, b.quantity, m.name medicine_name FROM medicine_batches b JOIN medicines m ON m.id=b.medicine_id WHERE b.deleted_at IS NULL AND m.deleted_at IS NULL ORDER BY m.name,b.expiry_date");
$recent=$conn->query('SELECT sa.*, m.name medicine_name, b.batch_number, u.name user_name FROM stock_adjustments sa JOIN medicines m ON m.id=sa.medicine_id JOIN medicine_batches b ON b.id=sa.batch_id LEFT JOIN users u ON u.id=sa.user_id ORDER BY sa.created_at DESC LIMIT 100');
include 'includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title"><?= t('stock_adjustments') ?></h1><p class="page-subtitle"><?= t('stock_adjustments_subtitle') ?></p></div></div>
  <?php if($message): ?><div class="alert <?= h($messageClass) ?>"><?= h($message) ?></div><?php endif; ?>
  <form class="form-card" method="POST"><?= csrf_field() ?><div class="form-grid"><div><label><?= t('batch') ?></label><select class="input" name="batch_id" required><option value=""><?= t('select_batch') ?></option><?php while($b=$batches->fetch_assoc()): ?><option value="<?= (int)$b['id'] ?>"><?= h($b['medicine_name']) ?> · #<?= h($b['batch_number']) ?> · Stock <?= (int)$b['quantity'] ?> · Exp <?= h($b['expiry_date']) ?></option><?php endwhile; ?></select></div><div><label>Movement type</label><select class="input" name="movement_type"><option value="adjustment">Adjustment</option><option value="expired_removal">Expired removal</option><option value="manual_correction">Manual correction</option></select></div><div><label>Quantity change</label><input class="input" type="number" name="quantity_change" required placeholder="Example: -5 or 10"></div><div><label>Reason</label><input class="input" name="reason" required placeholder="Damaged, expired, count correction..."></div></div><br><button class="btn">Save Adjustment</button></form>
  <br><div class="table-card"><div class="table-header"><h2><?= t('recent_adjustments') ?></h2></div><div class="table-scroll"><table><thead><tr><th><?= t('medicine') ?></th><th><?= t('batch') ?></th><th><?= t('change') ?></th><th><?= t('reason') ?></th><th><?= t('user') ?></th><th><?= t('date') ?></th></tr></thead><tbody><?php while($r=$recent->fetch_assoc()): ?><tr><td><?= h($r['medicine_name']) ?></td><td class="mono"><?= h($r['batch_number']) ?></td><td><?= (int)$r['quantity_change'] ?></td><td><?= h($r['reason']) ?></td><td><?= h($r['user_name'] ?? '-') ?></td><td><?= h($r['created_at']) ?></td></tr><?php endwhile; ?></tbody></table></div></div>
</div>
<?php include 'includes/footer.php'; ?>
