<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
require_role(['admin','manager']); ensure_real_pharmacy_schema($conn);
ensure_purchase_tables($conn);

$message = '';
$messageClass = '';
$suppliers = $conn->query('SELECT id,name FROM suppliers WHERE deleted_at IS NULL ORDER BY name');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $supplierId = (int)($_POST['supplier_id'] ?? 0);
    $invoice = trim($_POST['invoice_number'] ?? '');
    $date = $_POST['purchase_date'] ?: date('Y-m-d');
    $status = strtoupper($_POST['status'] ?? 'PAID');
    $allowedStatus = ['PAID','PARTIAL','UNPAID'];
    if (!in_array($status, $allowedStatus, true)) $status = 'PAID';

    $items = $_POST['items'] ?? [];
    $validItems = [];
    $totalAmount = 0.0;
    foreach ($items as $item) {
        $name = trim($item['medicine_name'] ?? '');
        $batch = trim($item['batch_number'] ?? '');
        $expiry = $item['expiry_date'] ?? '';
        $qty = max(0, (int)($item['quantity'] ?? 0));
        $purchasePrice = max(0, (float)($item['purchase_price'] ?? 0));
        $sellingPrice = max(0, (float)($item['selling_price'] ?? 0));
        if ($name === '' || $batch === '' || $expiry === '' || $qty <= 0) continue;
        $lineTotal = $qty * $purchasePrice;
        $validItems[] = compact('name', 'batch', 'expiry', 'qty', 'purchasePrice', 'sellingPrice', 'lineTotal');
        $totalAmount += $lineTotal;
    }

    if (!$supplierId || $invoice === '' || empty($validItems)) {
        $message = 'Please choose a supplier, invoice number, and at least one valid item.';
        $messageClass = 'bad';
    } else {
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare('INSERT INTO purchases(invoice_number,supplier_id,purchase_date,status,total_amount,user_id) VALUES(?,?,?,?,?,?)');
            $userId = (int)($_SESSION['user_id'] ?? 0);
            $stmt->bind_param('sissdi', $invoice, $supplierId, $date, $status, $totalAmount, $userId);
            $stmt->execute();
            $purchaseId = $conn->insert_id;
            $stmt->close();

            foreach ($validItems as $item) {
                $stmt = $conn->prepare('SELECT id FROM medicines WHERE name=? LIMIT 1');
                $stmt->bind_param('s', $item['name']);
                $stmt->execute();
                $medicine = $stmt->get_result()->fetch_assoc();
                $stmt->close();

                if ($medicine) {
                    $medicineId = (int)$medicine['id'];
                } else {
                    $empty = '';
                    $minStock = 10;
                    $medicineName = $item['name'];
                    $stmt = $conn->prepare('INSERT INTO medicines(name,generic_name,barcode,category,min_stock) VALUES(?,?,?,?,?)');
                    $stmt->bind_param('ssssi', $medicineName, $empty, $empty, $empty, $minStock);
                    $stmt->execute();
                    $medicineId = $conn->insert_id;
                    $stmt->close();
                }

                $batchNumber = $item['batch'];
                $expiryDate = $item['expiry'];
                $quantity = $item['qty'];
                $purchasePrice = $item['purchasePrice'];
                $sellingPrice = $item['sellingPrice'];
                $lineTotal = $item['lineTotal'];
                $stmt = $conn->prepare('INSERT INTO medicine_batches(medicine_id,supplier_id,batch_number,expiry_date,quantity,purchase_price,selling_price) VALUES(?,?,?,?,?,?,?)');
                $stmt->bind_param('iissidd', $medicineId, $supplierId, $batchNumber, $expiryDate, $quantity, $purchasePrice, $sellingPrice);
                $stmt->execute();
                $batchId = $conn->insert_id;
                $stmt->close();

                $stmt = $conn->prepare('INSERT INTO purchase_items(purchase_id,medicine_id,batch_id,quantity,purchase_price,selling_price,total) VALUES(?,?,?,?,?,?,?)');
                $stmt->bind_param('iiiiddd', $purchaseId, $medicineId, $batchId, $quantity, $purchasePrice, $sellingPrice, $lineTotal);
                $stmt->execute();
                $stmt->close();

                record_stock_movement($conn, $medicineId, $batchId, $quantity, 'purchase', 'Supplier invoice ' . $invoice, 'purchases', $purchaseId);
                log_audit($conn, 'create_purchase_batch', 'medicine_batches', $batchId, null, get_row_by_id($conn, 'medicine_batches', $batchId));
            }

            log_audit($conn, 'create_purchase', 'purchases', $purchaseId, null, get_row_by_id($conn, 'purchases', $purchaseId));
            $conn->commit();
            header('Location: purchases.php');
            exit;
        } catch (Throwable $e) {
            $conn->rollback();
            $message = 'Could not save purchase. Check that the invoice number is unique.';
            $messageClass = 'bad';
        }
    }
}

include 'includes/header.php';
?>
<div class="content">
  <div class="page-head">
    <div>
      <h1 class="page-title"><?= t('add_purchase') ?></h1>
      <p class="page-subtitle"><?= t('purchase_form_subtitle') ?></p>
    </div>
    <a class="btn secondary" href="purchases.php"><span class="material-symbols-outlined">arrow_back</span><?= t('purchases') ?></a>
  </div>

  <?php if ($message): ?><div class="alert <?= h($messageClass) ?>"><?= h($message) ?></div><?php endif; ?>

  <form method="POST" class="form-card" id="purchase-form">
    <?= csrf_field() ?>
    <h2 class="section-title" style="margin-top:0"><?= t('invoice') ?></h2>
    <div class="form-grid">
      <div>
        <label><?= t('supplier') ?></label>
        <select class="input" name="supplier_id" required>
          <option value="">-- Select supplier --</option>
          <?php while($s = $suppliers->fetch_assoc()): ?>
            <option value="<?= (int)$s['id'] ?>"><?= h($s['name']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div><label><?= t('invoice') ?></label><input class="input" name="invoice_number" value="PO-<?= date('Ymd-His') ?>" required></div>
      <div><label><?= t('date') ?></label><input class="input" name="purchase_date" type="date" value="<?= date('Y-m-d') ?>" required></div>
      <div>
        <label><?= t('payment_status') ?></label>
        <select class="input" name="status">
          <option value="PAID"><?= t('paid') ?></option>
          <option value="PARTIAL"><?= t('partial') ?></option>
          <option value="UNPAID"><?= t('unpaid') ?></option>
        </select>
      </div>
    </div>

    <h2 class="section-title"><?= t('items') ?></h2>
    <div class="table-card">
      <div class="table-scroll">
        <table>
          <thead><tr><th><?= t('name') ?></th><th><?= t('batch_number') ?></th><th><?= t('expiry_date') ?></th><th><?= t('quantity') ?></th><th><?= t('purchase_price') ?></th><th><?= t('selling_price') ?></th><th><?= t('total') ?></th><th></th></tr></thead>
          <tbody id="purchase-items">
            <tr>
              <td><input class="input" name="items[0][medicine_name]" required></td>
              <td><input class="input" name="items[0][batch_number]" required></td>
              <td><input class="input" name="items[0][expiry_date]" type="date" required></td>
              <td><input class="input line-qty" name="items[0][quantity]" type="number" min="1" value="1" required></td>
              <td><input class="input line-price" name="items[0][purchase_price]" type="number" step="0.01" min="0" value="0" required></td>
              <td><input class="input" name="items[0][selling_price]" type="number" step="0.01" min="0" value="0" required></td>
              <td class="mono line-total">0 IQD</td>
              <td><button class="btn danger remove-line" type="button"><span class="material-symbols-outlined">delete</span></button></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="actions-row" style="margin-top:14px;justify-content:space-between">
      <button type="button" class="btn secondary" id="add-item"><span class="material-symbols-outlined">add</span><?= t('add_item') ?></button>
      <strong><?= t('total') ?>: <span id="purchase-total" class="mono">0 IQD</span></strong>
    </div>
    <div class="actions-row" style="margin-top:24px">
      <button class="btn" type="submit"><span class="material-symbols-outlined">save</span><?= t('save') ?></button>
      <a class="btn secondary" href="purchases.php"><?= t('cancel') ?></a>
    </div>
  </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function(){
  const tbody = document.getElementById('purchase-items');
  const totalEl = document.getElementById('purchase-total');
  const addBtn = document.getElementById('add-item');

  function money(v){ return Number(v || 0).toLocaleString(undefined,{maximumFractionDigits:0}) + ' IQD'; }
  function renumber(){
    tbody.querySelectorAll('tr').forEach((tr, idx) => {
      tr.querySelectorAll('input').forEach(input => {
        input.name = input.name.replace(/items\[\d+\]/, 'items[' + idx + ']');
      });
    });
  }
  function recalc(){
    let total = 0;
    tbody.querySelectorAll('tr').forEach(tr => {
      const qty = Number(tr.querySelector('.line-qty').value || 0);
      const price = Number(tr.querySelector('.line-price').value || 0);
      const line = qty * price;
      tr.querySelector('.line-total').textContent = money(line);
      total += line;
    });
    totalEl.textContent = money(total);
  }
  function bindRow(tr){
    tr.querySelectorAll('input').forEach(input => input.addEventListener('input', recalc));
    tr.querySelector('.remove-line').addEventListener('click', function(){
      if (tbody.children.length > 1) tr.remove();
      renumber();
      recalc();
    });
  }
  addBtn.addEventListener('click', function(){
    const idx = tbody.children.length;
    const tr = tbody.children[0].cloneNode(true);
    tr.querySelectorAll('input').forEach(input => {
      input.name = input.name.replace(/items\[\d+\]/, 'items[' + idx + ']');
      input.value = input.type === 'number' ? (input.classList.contains('line-qty') ? '1' : '0.00') : '';
    });
    tr.querySelector('.line-total').textContent = '0 IQD';
    tbody.appendChild(tr);
    bindRow(tr);
    recalc();
  });
  tbody.querySelectorAll('tr').forEach(bindRow);
  recalc();
});
</script>
<?php include 'includes/footer.php'; ?>
