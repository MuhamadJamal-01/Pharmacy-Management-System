<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
require_role(['admin','manager']); ensure_real_pharmacy_schema($conn);
ensure_purchase_tables($conn);

$supplierFilter = (int)($_GET['supplier_id'] ?? 0);
$statusFilter = strtoupper($_GET['status'] ?? '');
$where = [];
$params = [];
$types = '';
if ($supplierFilter > 0) {
  $where[] = 'p.supplier_id = ?';
  $params[] = $supplierFilter;
  $types .= 'i';
}
if (in_array($statusFilter, ['PAID','PARTIAL','UNPAID'], true)) {
  $where[] = 'p.status = ?';
  $params[] = $statusFilter;
  $types .= 's';
}

$sql = 'SELECT p.*, s.name supplier_name, u.name user_name, COUNT(pi.id) item_count
        FROM purchases p
        LEFT JOIN suppliers s ON s.id=p.supplier_id
        LEFT JOIN users u ON u.id=p.user_id
        LEFT JOIN purchase_items pi ON pi.purchase_id=p.id';
if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
$sql .= ' GROUP BY p.id ORDER BY p.purchase_date DESC, p.id DESC LIMIT 100';

if ($params) {
  $stmt = $conn->prepare($sql);
  $bind = [$types];
  foreach ($params as $i => $value) { $bindName = 'p' . $i; $$bindName = $value; $bind[] = &$$bindName; }
  call_user_func_array([$stmt, 'bind_param'], $bind);
  $stmt->execute();
  $rows = $stmt->get_result();
} else {
  $rows = $conn->query($sql);
}

$suppliers = $conn->query('SELECT id,name FROM suppliers WHERE deleted_at IS NULL ORDER BY name');
$summary = $conn->query("SELECT COUNT(*) count, COALESCE(SUM(total_amount),0) total FROM purchases WHERE MONTH(purchase_date)=MONTH(CURDATE()) AND YEAR(purchase_date)=YEAR(CURDATE())")->fetch_assoc();
$pending = $conn->query("SELECT COUNT(*) count FROM purchases WHERE status IN ('PARTIAL','UNPAID')")->fetch_assoc()['count'];

include 'includes/header.php';
?>
<div class="content">
  <div class="page-head">
    <div>
      <h1 class="page-title"><?= t('purchases') ?></h1>
      <p class="page-subtitle"><?= t('purchases_subtitle') ?></p>
    </div>
    <a class="btn" href="purchase_form.php"><span class="material-symbols-outlined">add_shopping_cart</span><?= t('add_purchase') ?></a>
  </div>

  <div class="cards">
    <div class="card"><h3><?= t('this_month') ?></h3><p><?= money($summary['total']) ?></p><div class="mini"><?= (int)$summary['count'] ?> <?= t('purchase_invoices') ?></div></div>
    <div class="card"><h3><?= t('pending') ?></h3><p><?= (int)$pending ?></p><div class="mini"><?= t('partial_unpaid_invoices') ?></div></div>
    <div class="card"><h3><?= t('suppliers') ?></h3><p><?= $suppliers->num_rows ?></p><div class="mini"><?= t('available_supplier_accounts') ?></div></div>
    <div class="card"><h3><?= t('inventory') ?></h3><p><?= (int)$conn->query('SELECT COALESCE(SUM(quantity),0) stock FROM medicine_batches')->fetch_assoc()['stock'] ?></p><div class="mini"><?= t('units_currently_in_stock') ?></div></div>
  </div>

  <form class="filters" method="GET">
    <div class="filter-field">
      <label><?= t('supplier') ?></label>
      <select name="supplier_id">
        <option value=""><?= t('all_suppliers') ?></option>
        <?php $suppliers->data_seek(0); while($s = $suppliers->fetch_assoc()): ?>
          <option value="<?= (int)$s['id'] ?>" <?= $supplierFilter === (int)$s['id'] ? 'selected' : '' ?>><?= h($s['name']) ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="filter-field">
      <label><?= t('status') ?></label>
      <select name="status">
        <option value=""><?= t('all_statuses') ?></option>
        <option value="PAID" <?= $statusFilter === 'PAID' ? 'selected' : '' ?>><?= t('paid') ?></option>
        <option value="PARTIAL" <?= $statusFilter === 'PARTIAL' ? 'selected' : '' ?>><?= t('partial') ?></option>
        <option value="UNPAID" <?= $statusFilter === 'UNPAID' ? 'selected' : '' ?>><?= t('unpaid') ?></option>
      </select>
    </div>
    <button type="submit" class="btn secondary"><span class="material-symbols-outlined">filter_list</span><?= t('search') ?></button>
    <a class="btn secondary" href="purchases.php"><span class="material-symbols-outlined">refresh</span><?= t('reset') ?></a>
  </form>

  <div class="table-card">
    <div class="table-header"><h2><?= t('purchases') ?></h2></div>
    <div class="table-scroll">
      <table>
        <thead><tr><th><?= t('invoice') ?></th><th><?= t('supplier') ?></th><th><?= t('date') ?></th><th><?= t('items') ?></th><th><?= t('total') ?></th><th><?= t('status') ?></th><th><?= t('user') ?></th><th><?= t('actions') ?></th></tr></thead>
        <tbody>
        <?php if ($rows && $rows->num_rows): ?>
          <?php while($r = $rows->fetch_assoc()): ?>
            <?php $badge = $r['status'] === 'PAID' ? 'ok' : ($r['status'] === 'PARTIAL' ? 'warn' : 'bad'); ?>
            <tr>
              <td class="mono"><strong><?= h($r['invoice_number']) ?></strong></td>
              <td><?= h($r['supplier_name'] ?? '-') ?></td>
              <td><?= h($r['purchase_date']) ?></td>
              <td><?= (int)$r['item_count'] ?></td>
              <td><?= money($r['total_amount']) ?></td>
              <td><span class="badge <?= $badge ?>"><?= h(ucfirst(strtolower($r['status']))) ?></span></td>
              <td><?= h($r['user_name'] ?? '-') ?></td><td><a class="btn secondary" href="purchase_view.php?id=<?= (int)$r['id'] ?>"><?= t('view') ?></a></td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="8" class="muted"><?= t('no_purchases_yet') ?></td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
