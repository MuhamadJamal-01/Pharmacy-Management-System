<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin','manager']); ensure_real_pharmacy_schema($conn);
if ($_SERVER['REQUEST_METHOD']==='POST') {
  verify_csrf();
  $action = $_POST['action'] ?? 'create';
  if ($action === 'delete') {
    $id=(int)($_POST['id'] ?? 0); $old=get_row_by_id($conn,'suppliers',$id);
    if ($old) { $stmt=$conn->prepare('UPDATE suppliers SET deleted_at=NOW() WHERE id=?'); $stmt->bind_param('i',$id); $stmt->execute(); $stmt->close(); log_audit($conn,'soft_delete_supplier','suppliers',$id,$old,null); }
  } else {
    $name=trim($_POST['name'] ?? ''); $phone=trim($_POST['phone'] ?? ''); $address=trim($_POST['address'] ?? '');
    if ($name !== '') { $stmt=$conn->prepare('INSERT INTO suppliers(name,phone,address) VALUES(?,?,?)'); $stmt->bind_param('sss',$name,$phone,$address); $stmt->execute(); $id=$conn->insert_id; $stmt->close(); log_audit($conn,'create_supplier','suppliers',$id,null,get_row_by_id($conn,'suppliers',$id)); }
  }
  redirect('suppliers.php');
}
$rows=$conn->query('SELECT * FROM suppliers WHERE deleted_at IS NULL ORDER BY name'); include 'includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title"><?= t('suppliers') ?></h1><p class="page-subtitle"><?= t('supplier_management') ?></p></div></div>
  <div class="split-grid"><form class="form-card" method="POST"><?= csrf_field() ?><h2 class="section-title" style="margin-top:0"><?= t('add_supplier') ?></h2><div class="form-grid"><div><label><?= t('name') ?></label><input class="input" name="name" required></div><div><label><?= t('phone') ?></label><input class="input" name="phone"></div><div style="grid-column:1/-1"><label>Address</label><textarea class="input" name="address" rows="2"></textarea></div></div><br><button class="btn"><span class="material-symbols-outlined">save</span><?= t('save') ?></button></form><div class="card quick-stat"><h3><?= t('suppliers') ?></h3><p><?= $rows->num_rows ?></p><div>Active supplier accounts</div></div></div><br>
  <div class="table-card"><div class="table-header"><h2><?= t('suppliers') ?></h2></div><div class="table-scroll"><table><thead><tr><th><?= t('name') ?></th><th><?= t('phone') ?></th><th><?= t('address') ?></th><th><?= t('status') ?></th><th><?= t('actions') ?></th></tr></thead><tbody><?php while($r=$rows->fetch_assoc()): ?><tr><td><strong><?= h($r['name']) ?></strong></td><td><?= h($r['phone']) ?></td><td><?= h($r['address'] ?? '') ?></td><td><span class="badge ok"><?= t('active') ?></span></td><td><form method="POST" onsubmit="return confirm('Delete this supplier?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn danger" type="submit"><?= t('delete') ?></button></form></td></tr><?php endwhile; ?></tbody></table></div></div>
</div>
<?php include 'includes/footer.php'; ?>
