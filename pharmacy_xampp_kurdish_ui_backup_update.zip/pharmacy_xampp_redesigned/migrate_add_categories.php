<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';
require_role(['admin','manager']);
ensure_real_pharmacy_schema($conn);

$sqlFile = __DIR__ . '/sql/add_categories_table.sql';
$output = '';
if (!file_exists($sqlFile)) {
    $output = 'Migration SQL file not found: ' . h($sqlFile);
} else {
    $sql = file_get_contents($sqlFile);
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        verify_csrf();
        if ($conn->multi_query($sql)) {
            // drain results
            do {
                if ($res = $conn->store_result()) { $res->free(); }
            } while ($conn->more_results() && $conn->next_result());
            if ($conn->errno) { $output = 'Error: ' . h($conn->error); }
            else { $output = 'Migration completed successfully.'; }
        } else {
            $output = 'Failed to execute migration: ' . h($conn->error);
        }
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title"><?= t('run_categories_migration') ?></h1><p class="page-subtitle"><?= t('run_categories_migration_subtitle') ?></p></div></div>
  <div class="card">
    <div class="content">
      <?php if ($output): ?><div class="alert ok"><?= $output ?></div><?php endif; ?>
      <?php if (file_exists($sqlFile)): ?>
        <pre style="max-height:240px;overflow:auto;border:1px solid #eee;padding:8px;background:#fafafa"><?= h(file_get_contents($sqlFile)) ?></pre>
        <form method="POST" style="margin-top:12px">
          <?= csrf_field() ?><button class="btn" type="submit"><?= t('run_migration') ?></button> <a class="btn secondary" href="categories.php"><?= t('back') ?></a></form>
      <?php else: ?>
        <div class="muted"><?= t('migration_file_missing') ?></div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
