<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
require_role(['admin','manager']); ensure_real_pharmacy_schema($conn);

if (isset($_GET['cancel'])) {
    unset($_SESSION['import_csv_raw']);
    header('Location: medicines_import.php');
    exit;
}

$message = '';
$errors = [];
$preview = false;
$previewRows = [];
$inserted = 0;
$updated = 0;
$batchesInserted = 0;
$batchesUpdated = 0;

function csv_columns($head) {
    return array_map(function($column) {
        return trim(strtolower((string)$column));
    }, $head);
}

function row_data($cols, $row) {
    $data = [];
    foreach ($cols as $i => $col) {
        $data[$col] = $row[$i] ?? '';
    }
    return $data;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm']) && !empty($_SESSION['import_csv_raw'])) {
    verify_csrf();
    $raw = $_SESSION['import_csv_raw'];
    $fh = fopen('data://text/plain;base64,' . base64_encode($raw), 'r');
    $head = $fh ? fgetcsv($fh) : false;

    if ($head === false) {
        $errors[] = 'CSV is empty.';
    } else {
        $cols = csv_columns($head);
        if (!in_array('name', $cols, true)) {
            $errors[] = "CSV must include a 'name' column.";
        } else {
            $conn->begin_transaction();
            try {
                while (($row = fgetcsv($fh)) !== false) {
                    if (count(array_filter($row, 'strlen')) === 0) continue;
                    $data = row_data($cols, $row);

                    $name = trim($data['name'] ?? '');
                    if ($name === '') continue;
                    $generic = trim($data['generic_name'] ?? $data['generic'] ?? '');
                    $barcode = trim($data['barcode'] ?? '');
                    $category = trim($data['category'] ?? '');
                    $minStock = max(0, (int)($data['min_stock'] ?? $data['minstock'] ?? 10));
                    $quantity = max(0, (int)($data['quantity'] ?? $data['qty'] ?? 0));
                    $expiry = trim($data['expiry_date'] ?? $data['expiry'] ?? '');
                    $purchasePrice = max(0, (float)($data['purchase_price'] ?? $data['purchaseprice'] ?? 0));
                    $sellingPrice = max(0, (float)($data['selling_price'] ?? $data['sellingprice'] ?? $data['price'] ?? 0));
                    $batchNumber = trim($data['batch_number'] ?? $data['batch'] ?? '');
                    $supplierRaw = trim($data['supplier'] ?? $data['supplier_name'] ?? $data['supplier_id'] ?? '');

                    $supplierId = null;
                    if ($supplierRaw !== '') {
                        if (ctype_digit($supplierRaw)) {
                            $sid = (int)$supplierRaw;
                            $stmt = $conn->prepare('SELECT id FROM suppliers WHERE id=? AND deleted_at IS NULL LIMIT 1');
                            $stmt->bind_param('i', $sid);
                            $stmt->execute();
                            if ($stmt->get_result()->fetch_assoc()) $supplierId = $sid;
                            $stmt->close();
                        } else {
                            $stmt = $conn->prepare('SELECT id FROM suppliers WHERE name=? AND deleted_at IS NULL LIMIT 1');
                            $stmt->bind_param('s', $supplierRaw);
                            $stmt->execute();
                            $supplier = $stmt->get_result()->fetch_assoc();
                            $stmt->close();
                            if ($supplier) {
                                $supplierId = (int)$supplier['id'];
                            } else {
                                $stmt = $conn->prepare('INSERT INTO suppliers(name) VALUES(?)');
                                $stmt->bind_param('s', $supplierRaw);
                                $stmt->execute();
                                $supplierId = $conn->insert_id;
                                $stmt->close();
                            }
                        }
                    }

                    $medicineId = null;
                    if ($barcode !== '') {
                        $stmt = $conn->prepare('SELECT id FROM medicines WHERE barcode=? AND deleted_at IS NULL LIMIT 1');
                        $stmt->bind_param('s', $barcode);
                        $stmt->execute();
                        $existing = $stmt->get_result()->fetch_assoc();
                        $stmt->close();
                        if ($existing) $medicineId = (int)$existing['id'];
                    }

                    if ($medicineId) {
                        $stmt = $conn->prepare('UPDATE medicines SET name=?, generic_name=?, category=?, min_stock=? WHERE id=?');
                        $stmt->bind_param('sssii', $name, $generic, $category, $minStock, $medicineId);
                        $stmt->execute();
                        $stmt->close();
                        $updated++;
                    } else {
                        $stmt = $conn->prepare('INSERT INTO medicines(name,generic_name,barcode,category,min_stock) VALUES(?,?,?,?,?)');
                        $stmt->bind_param('ssssi', $name, $generic, $barcode, $category, $minStock);
                        $stmt->execute();
                        $medicineId = $conn->insert_id;
                        $stmt->close();
                        $inserted++;
                    }

                    $hasBatch = $quantity > 0 || $batchNumber !== '' || $expiry !== '' || $purchasePrice > 0 || $sellingPrice > 0;
                    if ($hasBatch) {
                        if ($expiry === '') {
                            throw new RuntimeException("Batch expiry date is required for {$name}.");
                        }
                        if ($batchNumber === '') {
                            $batchNumber = 'IMP-' . date('YmdHis') . '-' . random_int(1000, 9999);
                        }

                        $stmt = $conn->prepare('SELECT id,quantity FROM medicine_batches WHERE medicine_id=? AND batch_number=? AND deleted_at IS NULL LIMIT 1');
                        $stmt->bind_param('is', $medicineId, $batchNumber);
                        $stmt->execute();
                        $batch = $stmt->get_result()->fetch_assoc();
                        $stmt->close();

                        if ($batch) {
                            $newQuantity = (int)$batch['quantity'] + $quantity;
                            $stmt = $conn->prepare('UPDATE medicine_batches SET supplier_id=?, quantity=?, expiry_date=?, purchase_price=?, selling_price=? WHERE id=?');
                            $batchId = (int)$batch['id'];
                            $stmt->bind_param('iisddi', $supplierId, $newQuantity, $expiry, $purchasePrice, $sellingPrice, $batchId);
                            $stmt->execute();
                            $stmt->close();
                            record_stock_movement($conn, $medicineId, $batchId, $quantity, 'purchase', 'CSV import batch update', 'medicine_batches', $batchId);
                            $batchesUpdated++;
                        } else {
                            $stmt = $conn->prepare('INSERT INTO medicine_batches(medicine_id,supplier_id,batch_number,expiry_date,quantity,purchase_price,selling_price) VALUES(?,?,?,?,?,?,?)');
                            $stmt->bind_param('iissidd', $medicineId, $supplierId, $batchNumber, $expiry, $quantity, $purchasePrice, $sellingPrice);
                            $stmt->execute();
                            $batchId = $conn->insert_id;
                            $stmt->close();
                            record_stock_movement($conn, $medicineId, $batchId, $quantity, 'purchase', 'CSV import new batch', 'medicine_batches', $batchId);
                            $batchesInserted++;
                        }
                    }
                }
                $conn->commit();
                unset($_SESSION['import_csv_raw']);
                log_audit($conn, 'medicines_csv_import', 'medicines', null, null, ['inserted'=>$inserted,'updated'=>$updated,'batchesInserted'=>$batchesInserted,'batchesUpdated'=>$batchesUpdated]);
                $message = "Import complete: {$inserted} inserted, {$updated} updated. Batches: {$batchesInserted} added, {$batchesUpdated} updated.";
            } catch (Throwable $e) {
                $conn->rollback();
                $errors[] = 'Database error: ' . $e->getMessage();
            }
        }
    }
    if ($fh) fclose($fh);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['confirm']) && isset($_FILES['csv']) && is_uploaded_file($_FILES['csv']['tmp_name'])) {
    verify_csrf();
    $tmp = $_FILES['csv']['tmp_name'];
    $fh = fopen($tmp, 'r');
    $head = $fh ? fgetcsv($fh) : false;
    if ($head === false) {
        $errors[] = 'CSV is empty.';
    } else {
        $cols = csv_columns($head);
        if (!in_array('name', $cols, true)) {
            $errors[] = "CSV must include a 'name' column.";
        } else {
            $count = 0;
            while (($row = fgetcsv($fh)) !== false && $count < 50) {
                if (count(array_filter($row, 'strlen')) === 0) continue;
                $previewRows[] = row_data($cols, $row);
                $count++;
            }
            $_SESSION['import_csv_raw'] = file_get_contents($tmp);
            $preview = true;
        }
    }
    if ($fh) fclose($fh);
}

include 'includes/header.php';
?>
<div class="content">
  <div class="page-head">
    <div><h1 class="page-title"><?= t('import_csv') ?></h1><p class="page-subtitle"><?= t('medicines') ?></p></div>
    <a class="btn secondary" href="medicines.php"><span class="material-symbols-outlined">arrow_back</span><?= t('medicines') ?></a>
  </div>
  <div class="form-card">
    <?php if ($message): ?><div class="alert ok"><?= h($message) ?></div><?php endif; ?>
    <?php foreach($errors as $error): ?><div class="alert bad"><?= h($error) ?></div><?php endforeach; ?>

    <?php if ($preview && $previewRows): ?>
      <h2 class="section-title" style="margin-top:0"><?= t('preview') ?></h2>
      <div class="table-card">
        <div class="table-scroll">
          <table>
            <thead><tr><?php foreach(array_keys($previewRows[0]) as $head): ?><th><?= h($head) ?></th><?php endforeach; ?></tr></thead>
            <tbody>
              <?php foreach($previewRows as $row): ?><tr><?php foreach($row as $value): ?><td><?= h($value) ?></td><?php endforeach; ?></tr><?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <form method="POST" class="actions-row" style="margin-top:16px">
        <?= csrf_field() ?>
        <button class="btn" type="submit" name="confirm" value="1"><span class="material-symbols-outlined">check</span><?= t('confirm_import') ?></button>
        <a class="btn secondary" href="medicines_import.php?cancel=1"><?= t('cancel') ?></a>
      </form>
    <?php else: ?>
      <form method="POST" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <label><?= t('upload_csv_file') ?></label>
        <input class="input" type="file" name="csv" accept=".csv" required>
        <p class="muted"><?= t('required_column_name') ?></p>
        <p class="muted">Optional columns: generic_name, barcode, category, min_stock, quantity, expiry_date, purchase_price, selling_price, batch_number, supplier.</p>
        <div class="actions-row" style="margin-top:16px">
          <button class="btn" type="submit"><span class="material-symbols-outlined">upload_file</span><?= t('upload_preview') ?></button>
          <a class="btn secondary" href="medicines.php"><?= t('cancel') ?></a>
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
