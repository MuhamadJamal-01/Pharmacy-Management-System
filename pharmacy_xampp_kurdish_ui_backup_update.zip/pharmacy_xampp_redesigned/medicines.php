<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
require_role(['admin','manager','pharmacist']); ensure_real_pharmacy_schema($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    verify_csrf();
    if (!has_role(['admin','manager'])) { http_response_code(403); exit('Access denied'); }
    $id = (int)($_POST['id'] ?? 0);
    $old = get_row_by_id($conn, 'medicines', $id);
    if ($old) {
        $stmt = $conn->prepare('UPDATE medicines SET deleted_at=NOW() WHERE id=?');
        $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
        log_audit($conn, 'soft_delete_medicine', 'medicines', $id, $old, null);
    }
    redirect('medicines.php');
}

$q = trim($_GET['q'] ?? '');
$category = trim($_GET['category'] ?? '');
$stock_status = trim($_GET['stock_status'] ?? '');

$baseSql = "SELECT m.*, COALESCE(SUM(CASE WHEN b.expiry_date >= CURDATE() AND b.deleted_at IS NULL THEN b.quantity ELSE 0 END),0) stock,
                   MIN(CASE WHEN b.quantity>0 AND b.deleted_at IS NULL THEN b.expiry_date END) nearest_expiry,
                   MAX(CASE WHEN b.deleted_at IS NULL THEN b.selling_price ELSE NULL END) max_price
            FROM medicines m
            LEFT JOIN medicine_batches b ON b.medicine_id=m.id";
$where = ['m.deleted_at IS NULL'];
$having = [];
$params = [];
$types = '';
if ($q !== '') {
  $where[] = '(m.name LIKE ? OR m.generic_name LIKE ? OR m.barcode LIKE ?)';
  $like = '%' . $q . '%';
  $params[] = $like; $params[] = $like; $params[] = $like; $types .= 'sss';
}
if ($category !== '') { $where[] = 'm.category = ?'; $params[] = $category; $types .= 's'; }
if ($stock_status !== '') {
  if ($stock_status === 'in_stock') $having[] = 'stock > 0';
  elseif ($stock_status === 'low_stock') $having[] = 'stock <= m.min_stock';
  elseif ($stock_status === 'expired') $having[] = 'SUM(CASE WHEN b.expiry_date < CURDATE() AND b.quantity>0 AND b.deleted_at IS NULL THEN b.quantity ELSE 0 END) > 0';
}
$sql = $baseSql . ' WHERE ' . implode(' AND ', $where) . ' GROUP BY m.id';
if ($having) $sql .= ' HAVING ' . implode(' AND ', $having);
$sql .= ' ORDER BY m.name';
if ($params) {
  $stmt = $conn->prepare($sql); $bind = [$types];
  foreach ($params as $i=>$v) { $name='p'.$i; $$name=$v; $bind[]=&$$name; }
  call_user_func_array([$stmt,'bind_param'],$bind); $stmt->execute(); $rows = $stmt->get_result();
} else { $rows = $conn->query($sql); }

$categories = [];
$res = $conn->query("SELECT name FROM categories WHERE deleted_at IS NULL ORDER BY name");
while($c = $res->fetch_assoc()) $categories[] = $c['name'];
include 'includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title"><?= t('medicines') ?></h1><p class="page-subtitle"><?= t('inventory_subtitle') ?></p></div><div class="actions-row"><a class="btn secondary" href="medicines_import.php"><span class="material-symbols-outlined">upload_file</span><?= t('import_csv') ?></a><a class="btn secondary" href="medicines_export.php"><span class="material-symbols-outlined">download</span><?= t('export') ?></a><a class="btn" href="medicine_form.php"><span class="material-symbols-outlined">add</span><?= t('add_medicine') ?></a></div></div>
  <form class="filters" method="GET">
    <div class="filter-field"><label><?= t('search') ?></label><input class="input" name="q" placeholder="<?= t('name') ?>, <?= t('generic_name') ?>, <?= t('barcode') ?>..." value="<?= h($q) ?>"></div>
    <div class="filter-field"><label><?= t('category') ?></label><select name="category"><option value=""><?= t('all_categories') ?></option><?php foreach($categories as $c): ?><option value="<?= h($c) ?>" <?= $category===$c ? 'selected' : '' ?>><?= h($c) ?></option><?php endforeach; ?></select></div>
    <div class="filter-field"><label><?= t('stock_status') ?></label><select name="stock_status"><option value=""><?= t('all_status') ?></option><option value="in_stock" <?= $stock_status==='in_stock'?'selected':'' ?>><?= t('in_stock') ?></option><option value="low_stock" <?= $stock_status==='low_stock'?'selected':'' ?>><?= t('low_stock') ?></option><option value="expired" <?= $stock_status==='expired'?'selected':'' ?>><?= t('expired') ?></option></select></div>
    <button type="submit" class="btn secondary"><span class="material-symbols-outlined">filter_list</span><?= t('search') ?></button>
  </form>
  <div class="table-card"><div class="table-scroll"><table><thead><tr><th><?= t('name') ?></th><th><?= t('generic_name') ?></th><th><?= t('category') ?></th><th><?= t('barcode') ?></th><th><?= t('rx') ?></th><th><?= t('total_stock') ?></th><th><?= t('nearest_expiry') ?></th><th><?= t('selling_price') ?></th><th><?= t('status') ?></th><th><?= t('actions') ?></th></tr></thead><tbody>
  <?php while($r=$rows->fetch_assoc()): $stock=(int)$r['stock']; $expiredRow = !empty($r['nearest_expiry']) && $r['nearest_expiry'] < date('Y-m-d'); $soon = !empty($r['nearest_expiry']) && $r['nearest_expiry'] <= date('Y-m-d', strtotime('+30 days')) && !$expiredRow; $status=$expiredRow?['bad',t('expired')]:($soon?['warn',t('expiring_soon')]:($stock <= (int)$r['min_stock'] ? ['warn',t('low_stock')] : ['ok',t('in_stock')])); ?>
    <tr><td><strong><?= h($r['name']) ?></strong></td><td class="muted"><?= h($r['generic_name']) ?></td><td><?= h($r['category']) ?></td><td class="mono"><?= h($r['barcode']) ?></td><td><?= !empty($r['requires_prescription']) ? '<span class="badge warn">' . t('required') . '</span>' : '<span class="badge ok">' . t('no') . '</span>' ?></td><td class="mono"><?= $stock ?></td><td class="<?= $expiredRow ? 'bad-text' : '' ?>"><?= h($r['nearest_expiry']) ?></td><td class="mono"><?= money($r['max_price']) ?></td><td><span class="badge <?= $status[0] ?>"><?= $status[1] ?></span></td><td><div class="toolbar"><a class="btn secondary" href="medicine_view.php?id=<?= (int)$r['id'] ?>"><span class="material-symbols-outlined">visibility</span><?= t('view') ?></a><a class="btn secondary" href="medicine_form.php?id=<?= (int)$r['id'] ?>"><span class="material-symbols-outlined">edit</span><?= t('edit') ?></a><?php if (has_role(['admin','manager'])): ?><form method="POST" style="display:inline" onsubmit="return confirmDelete()"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn danger" type="submit"><span class="material-symbols-outlined">delete</span><?= t('delete') ?></button></form><?php endif; ?></div></td></tr>
  <?php endwhile; ?></tbody></table></div></div>
</div>
<?php include 'includes/footer.php'; ?>
