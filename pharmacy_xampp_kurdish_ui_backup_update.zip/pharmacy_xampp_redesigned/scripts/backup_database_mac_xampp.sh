#!/bin/bash
# Automatic MariaDB backup for Mac XAMPP. Edit DB_NAME/paths if your setup is different.
DATE=$(date +"%Y-%m-%d_%H-%M-%S")
DB_NAME="pharmacy_db"
DB_USER="root"
DB_PASS=""
MYSQLDUMP="/Applications/XAMPP/xamppfiles/bin/mysqldump"
BACKUP_DIR="/Users/Shared/pharmacy_backups"
mkdir -p "$BACKUP_DIR"
if [ -z "$DB_PASS" ]; then
  "$MYSQLDUMP" -u "$DB_USER" "$DB_NAME" > "$BACKUP_DIR/pharmacy_backup_$DATE.sql"
else
  "$MYSQLDUMP" -u "$DB_USER" -p"$DB_PASS" "$DB_NAME" > "$BACKUP_DIR/pharmacy_backup_$DATE.sql"
fi
find "$BACKUP_DIR" -name "pharmacy_backup_*.sql" -mtime +30 -delete
