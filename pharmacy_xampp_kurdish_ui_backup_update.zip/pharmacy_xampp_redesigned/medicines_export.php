<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
require_role(['admin','manager','pharmacist']); ensure_real_pharmacy_schema($conn);
// If ?download=1, stream CSV and exit
if (isset($_GET['download']) && $_GET['download'] === '1') {
    $filename = 'medicines_export_' . date('Ymd_His') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $out = fopen('php://output','w');
    // header
    fputcsv($out, ['id','name','generic_name','barcode','category','requires_prescription','min_stock','created_at']);
    $res = $conn->query('SELECT id,name,generic_name,barcode,category,requires_prescription,min_stock,created_at FROM medicines WHERE deleted_at IS NULL ORDER BY name');
    while ($r = $res->fetch_assoc()) { fputcsv($out, [$r['id'],$r['name'],$r['generic_name'],$r['barcode'],$r['category'],$r['requires_prescription'],$r['min_stock'],$r['created_at']]); }
    fclose($out);
    exit;
}
include 'includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title"><?= t('export') ?></h1><p class="page-subtitle"><?= t('medicines') ?></p></div></div>
  <div class="card form-card">
    <p><?= t('export_medicines_csv') ?></p>
    <p><a class="btn" href="medicines_export.php?download=1"><?= t('download_csv') ?></a> <a class="btn secondary" href="medicines.php"><?= t('back_to_medicines') ?></a></p>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
