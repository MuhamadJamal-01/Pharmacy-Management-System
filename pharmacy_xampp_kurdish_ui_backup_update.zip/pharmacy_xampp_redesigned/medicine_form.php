<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin','manager','pharmacist']); ensure_real_pharmacy_schema($conn);
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$medicine = ['name'=>'','generic_name'=>'','barcode'=>'','category'=>'','min_stock'=>10,'requires_prescription'=>0,'unit_name'=>'unit'];
if ($id) {
  $stmt = $conn->prepare('SELECT * FROM medicines WHERE id=? AND deleted_at IS NULL');
  $stmt->bind_param('i', $id); $stmt->execute();
  $medicine = $stmt->get_result()->fetch_assoc(); $stmt->close();
  if (!$medicine) redirect('medicines.php');
}
$categories = [];
$res = $conn->query("SELECT name FROM categories WHERE deleted_at IS NULL ORDER BY name");
while($r=$res->fetch_assoc()) $categories[] = $r['name'];
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $old = $id ? get_row_by_id($conn, 'medicines', $id) : null;
    $name=trim($_POST['name'] ?? '');
    $generic=trim($_POST['generic_name'] ?? '');
    $barcode=trim($_POST['barcode'] ?? '');
    $category=trim($_POST['category'] ?? '');
    $min=max(0,(int)($_POST['min_stock'] ?? 0));
    $requires = isset($_POST['requires_prescription']) ? 1 : 0;
    $unit = trim($_POST['unit_name'] ?? 'unit'); if ($unit === '') $unit = 'unit';
    if ($id) {
        $stmt=$conn->prepare('UPDATE medicines SET name=?, generic_name=?, barcode=?, category=?, min_stock=?, requires_prescription=?, unit_name=? WHERE id=?');
        $stmt->bind_param('ssssiisi',$name,$generic,$barcode,$category,$min,$requires,$unit,$id); $stmt->execute(); $stmt->close();
        log_audit($conn, 'update_medicine', 'medicines', $id, $old, get_row_by_id($conn, 'medicines', $id));
    } else {
        $stmt=$conn->prepare('INSERT INTO medicines(name,generic_name,barcode,category,min_stock,requires_prescription,unit_name) VALUES(?,?,?,?,?,?,?)');
        $stmt->bind_param('ssssiis',$name,$generic,$barcode,$category,$min,$requires,$unit); $stmt->execute(); $id=$conn->insert_id; $stmt->close();
        log_audit($conn, 'create_medicine', 'medicines', $id, null, get_row_by_id($conn, 'medicines', $id));
    }
    if (!empty($_POST['batch_number'])) {
        $batch=trim($_POST['batch_number']); $expiry=$_POST['expiry_date']; $qty=max(0,(int)($_POST['quantity'] ?? 0)); $pp=max(0,(float)($_POST['purchase_price'] ?? 0)); $sp=max(0,(float)($_POST['selling_price'] ?? 0));
        if ($expiry !== '' && $qty > 0) {
            $stmt=$conn->prepare('INSERT INTO medicine_batches(medicine_id,batch_number,expiry_date,quantity,purchase_price,selling_price) VALUES(?,?,?,?,?,?)');
            $stmt->bind_param('issidd',$id,$batch,$expiry,$qty,$pp,$sp); $stmt->execute(); $batchId = $conn->insert_id; $stmt->close();
            record_stock_movement($conn, $id, $batchId, $qty, 'purchase', 'Initial/manual batch added from medicine form', 'medicine_batches', $batchId);
            log_audit($conn, 'create_batch', 'medicine_batches', $batchId, null, get_row_by_id($conn, 'medicine_batches', $batchId));
        }
    }
    redirect('medicines.php');
}
include 'includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title"><?= $id ? t('edit_medicine') : t('add_medicine') ?></h1><p class="page-subtitle"><?= t('inventory_subtitle') ?></p></div><a class="btn secondary" href="medicines.php"><span class="material-symbols-outlined">arrow_back</span><?= t('cancel') ?></a></div>
  <form class="form-card" method="POST">
    <?= csrf_field() ?>
    <h2 class="section-title" style="margin-top:0"><?= t('medicine_details') ?></h2>
    <div class="form-grid">
      <div><label><?= t('name') ?></label><input class="input" name="name" value="<?= h($medicine['name']) ?>" required></div>
      <div><label><?= t('generic_name') ?></label><input class="input" name="generic_name" value="<?= h($medicine['generic_name']) ?>"></div>
      <div><label><?= t('barcode') ?></label><input class="input" name="barcode" value="<?= h($medicine['barcode']) ?>"></div>
      <div><label><?= t('category') ?></label><select class="input" name="category"><option value="">-- <?= t('select_category') ?> --</option><?php foreach($categories as $c): ?><option value="<?= h($c) ?>" <?= ($medicine['category']===$c)?'selected':'' ?>><?= h($c) ?></option><?php endforeach; ?></select></div>
      <div><label><?= t('minimum_stock') ?></label><input class="input" type="number" name="min_stock" min="0" value="<?= h($medicine['min_stock']) ?>"></div>
      <div><label><?= t('unit') ?></label><input class="input" name="unit_name" value="<?= h($medicine['unit_name'] ?? 'unit') ?>" placeholder="<?= t('unit_placeholder') ?>"></div>
      <div style="display:flex;align-items:end;gap:10px"><label style="display:flex;gap:10px;align-items:center"><input type="checkbox" name="requires_prescription" value="1" <?= !empty($medicine['requires_prescription']) ? 'checked' : '' ?>> Prescription required</label></div>
    </div>
    <h2 class="section-title"><?= t('add_batch') ?></h2>
    <div class="form-grid">
      <div><label><?= t('batch_number') ?></label><input class="input" name="batch_number"></div>
      <div><label><?= t('expiry_date') ?></label><input class="input" type="date" name="expiry_date"></div>
      <div><label><?= t('quantity') ?></label><input class="input" type="number" min="0" name="quantity"></div>
      <div><label><?= t('purchase_price') ?> (IQD)</label><input class="input" type="number" step="1" min="0" name="purchase_price"></div>
      <div><label><?= t('selling_price') ?> (IQD)</label><input class="input" type="number" step="1" min="0" name="selling_price"></div>
    </div>
    <div class="actions-row" style="margin-top:24px"><button class="btn"><span class="material-symbols-outlined">save</span><?= t('save') ?></button><a class="btn secondary" href="medicines.php"><?= t('cancel') ?></a></div>
  </form>
</div>
<?php include 'includes/footer.php'; ?>
