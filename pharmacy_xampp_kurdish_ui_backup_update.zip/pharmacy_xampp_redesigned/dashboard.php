<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
require_role(['admin','manager','pharmacist','cashier']); ensure_real_pharmacy_schema($conn);
$medicines = $conn->query('SELECT COUNT(*) c FROM medicines WHERE deleted_at IS NULL')->fetch_assoc()['c'];
$low = $conn->query('SELECT COUNT(*) c FROM medicines m WHERE m.deleted_at IS NULL AND (SELECT COALESCE(SUM(quantity),0) FROM medicine_batches b WHERE b.medicine_id=m.id AND b.deleted_at IS NULL) <= m.min_stock')->fetch_assoc()['c'];
$expired = $conn->query('SELECT COUNT(*) c FROM medicine_batches WHERE deleted_at IS NULL AND expiry_date < CURDATE() AND quantity > 0')->fetch_assoc()['c'];
$expiring = $conn->query('SELECT COUNT(*) c FROM medicine_batches WHERE deleted_at IS NULL AND expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) AND quantity > 0')->fetch_assoc()['c'];
$sales = $conn->query('SELECT COALESCE(SUM(total_amount),0) total FROM sales WHERE DATE(created_at)=CURDATE()')->fetch_assoc()['total'];
$monthly = $conn->query('SELECT COALESCE(SUM(total_amount),0) total FROM sales WHERE MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE())')->fetch_assoc()['total'];
$inventory = $conn->query('SELECT COALESCE(SUM(quantity*purchase_price),0) total FROM medicine_batches WHERE deleted_at IS NULL')->fetch_assoc()['total'];
$recent = $conn->query('SELECT s.*, u.name user_name FROM sales s LEFT JOIN users u ON u.id=s.user_id ORDER BY s.created_at DESC LIMIT 5');
$lowRows = $conn->query('SELECT m.name, m.min_stock, COALESCE(SUM(b.quantity),0) stock FROM medicines m LEFT JOIN medicine_batches b ON b.medicine_id=m.id AND b.deleted_at IS NULL WHERE m.deleted_at IS NULL GROUP BY m.id HAVING stock <= m.min_stock ORDER BY stock ASC LIMIT 5');
include 'includes/header.php';
?>
<?php
// Prepare 7-day inbound (batches created) and dispensed (sale_items via sales.created_at) data
$days = 7;
$labels = [];
for ($i = $days - 1; $i >= 0; $i--) {
  $d = date('Y-m-d', strtotime("-{$i} days"));
  $labels[] = date('M j', strtotime($d));
}

$startDate = date('Y-m-d', strtotime('-' . ($days - 1) . ' days'));
$inboundRows = $conn->query("SELECT DATE(created_at) dt, COALESCE(SUM(quantity),0) total FROM medicine_batches WHERE deleted_at IS NULL AND DATE(created_at) >= '$startDate' GROUP BY DATE(created_at)");
$inboundMap = [];
while ($r = $inboundRows->fetch_assoc()) { $inboundMap[$r['dt']] = (int)$r['total']; }

$dispensedRows = $conn->query("SELECT DATE(s.created_at) dt, COALESCE(SUM(si.quantity),0) total FROM sales s JOIN sale_items si ON si.sale_id=s.id WHERE DATE(s.created_at) >= '$startDate' GROUP BY DATE(s.created_at)");
$dispensedMap = [];
while ($r = $dispensedRows->fetch_assoc()) { $dispensedMap[$r['dt']] = (int)$r['total']; }

$inboundData = [];
$dispensedData = [];
for ($i = $days - 1; $i >= 0; $i--) {
  $d = date('Y-m-d', strtotime("-{$i} days"));
  $inboundData[] = $inboundMap[$d] ?? 0;
  $dispensedData[] = $dispensedMap[$d] ?? 0;
}
?>
<div class="content">
  <div class="page-head">
    <div><h1 class="page-title"><?= t('dashboard') ?></h1><p class="page-subtitle"><?= t('dashboard_subtitle') ?></p></div>
    <div class="actions-row"><a class="btn" href="pos.php"><span class="material-symbols-outlined">point_of_sale</span><?= t('pos') ?></a><a class="btn secondary" href="medicine_form.php"><span class="material-symbols-outlined">add</span><?= t('add_medicine') ?></a></div>
  </div>
  <div class="cards">
    <div class="card"><h3><?= t('today_sales') ?></h3><p><?= money($sales) ?></p><div class="mini"><?= t('live_pos_revenue') ?></div></div>
    <div class="card"><h3><?= t('monthly_sales') ?></h3><p><?= money($monthly) ?></p><div class="mini"><?= t('current_month') ?></div></div>
    <div class="card"><h3><?= t('total_medicines') ?></h3><p><?= h($medicines) ?></p><div class="mini"><?= t('active_inventory_records') ?></div></div>
    <div class="card"><h3><?= t('inventory_value') ?></h3><p><?= money($inventory) ?></p><div class="mini"><?= t('purchase_cost_valuation') ?></div></div>
  </div>
  <div class="split-grid">
    <section class="table-card">
      <div class="table-header"><h2><?= t('stock_trend') ?></h2><div class="toolbar"><span class="badge ok"><?= t('inbound') ?></span><span class="badge warn"><?= t('dispensed') ?></span></div></div>
      <div style="padding:18px">
        <canvas id="stockTrendChart" style="width:100%;height:220px"></canvas>
      </div>
    </section>
    <section class="card quick-stat">
      <h3><?= t('quick_stats') ?></h3>
      <p><?= h($medicines) ?></p>
      <div><?= t('active_medicines') ?></div>
      <div class="stat-line"><span><?= t('low_stock') ?></span><strong><?= h($low) ?></strong></div>
      <div class="stat-line"><span><?= t('expired') ?></span><strong><?= h($expired) ?></strong></div>
      <div class="stat-line"><span><?= t('expiring_soon') ?></span><strong><?= h($expiring) ?></strong></div>
    </section>
  </div>
  <div class="split-grid" style="margin-top:20px">
    <section class="table-card"><div class="table-header"><h2><?= t('recent_activity') ?></h2></div><div class="table-scroll"><table><thead><tr><th><?= t('invoice') ?></th><th><?= t('total') ?></th><th><?= t('user') ?></th><th><?= t('date') ?></th></tr></thead><tbody><?php while($s=$recent->fetch_assoc()): ?><tr><td class="mono"><?= h($s['invoice_number']) ?></td><td><?= money($s['total_amount']) ?></td><td><?= h($s['user_name'] ?? '-') ?></td><td><?= h($s['created_at']) ?></td></tr><?php endwhile; ?></tbody></table></div></section>
    <section class="table-card"><div class="table-header"><h2><?= t('low_stock_items') ?></h2></div><div class="table-scroll"><table><thead><tr><th><?= t('name') ?></th><th><?= t('quantity') ?></th><th><?= t('minimum_stock') ?></th></tr></thead><tbody><?php while($r=$lowRows->fetch_assoc()): ?><tr><td><?= h($r['name']) ?></td><td><span class="badge warn"><?= (int)$r['stock'] ?></span></td><td><?= (int)$r['min_stock'] ?></td></tr><?php endwhile; ?></tbody></table></div></section>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
