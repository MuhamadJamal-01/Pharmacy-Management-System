<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin','manager']); ensure_real_pharmacy_schema($conn);
$q=trim($_GET['q'] ?? ''); $where=''; $params=[]; $types='';
if ($q!=='') { $where='WHERE al.action LIKE ? OR al.table_name LIKE ? OR u.name LIKE ?'; $like='%'.$q.'%'; $params=[$like,$like,$like]; $types='sss'; }
$sql="SELECT al.*, u.name user_name FROM audit_logs al LEFT JOIN users u ON u.id=al.user_id $where ORDER BY al.created_at DESC LIMIT 300";
if($params){ $stmt=$conn->prepare($sql); $stmt->bind_param($types,$params[0],$params[1],$params[2]); $stmt->execute(); $rows=$stmt->get_result(); } else $rows=$conn->query($sql);
include 'includes/header.php';
?>
<div class="content"><div class="page-head"><div><h1 class="page-title"><?= t('audit_logs') ?></h1><p class="page-subtitle"><?= t('audit_logs_subtitle') ?></p></div></div>
<form class="filters" method="GET"><div class="filter-field"><label><?= t('search') ?></label><input class="input" name="q" value="<?= h($q) ?>" placeholder="<?= t('search_audit_placeholder') ?>"></div><button class="btn secondary"><?= t('search') ?></button></form>
<div class="table-card"><div class="table-scroll"><table><thead><tr><th><?= t('date') ?></th><th><?= t('user') ?></th><th><?= t('action') ?></th><th><?= t('table') ?></th><th><?= t('record') ?></th><th><?= t('ip_address') ?></th><th><?= t('user_agent') ?></th></tr></thead><tbody><?php while($r=$rows->fetch_assoc()): ?><tr><td><?= h($r['created_at']) ?></td><td><?= h($r['user_name'] ?? '-') ?></td><td><?= h($r['action']) ?></td><td><?= h($r['table_name']) ?></td><td><?= h($r['record_id']) ?></td><td><?= h($r['ip_address']) ?></td><td class="muted"><?= h($r['user_agent']) ?></td></tr><?php endwhile; ?></tbody></table></div></div></div>
<?php include 'includes/footer.php'; ?>
