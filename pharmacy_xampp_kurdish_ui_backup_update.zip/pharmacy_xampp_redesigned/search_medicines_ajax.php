<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin','manager','pharmacist','cashier']); ensure_real_pharmacy_schema($conn);
$q = trim($_GET['q'] ?? '');
header('Content-Type: application/json; charset=utf-8');
if ($q === '') { echo json_encode([]); exit; }
$like = '%' . $q . '%';
$stmt = $conn->prepare("SELECT m.id,m.name,m.generic_name,m.requires_prescription,
    COALESCE(SUM(CASE WHEN b.expiry_date >= CURDATE() AND b.deleted_at IS NULL THEN b.quantity ELSE 0 END),0) stock,
    MIN(CASE WHEN b.expiry_date >= CURDATE() AND b.quantity>0 AND b.deleted_at IS NULL THEN b.selling_price END) price
  FROM medicines m
  LEFT JOIN medicine_batches b ON b.medicine_id=m.id
  WHERE m.deleted_at IS NULL AND (m.name LIKE ? OR m.generic_name LIKE ? OR m.barcode LIKE ?)
  GROUP BY m.id HAVING stock > 0 ORDER BY m.name LIMIT 20");
$stmt->bind_param('sss',$like,$like,$like); $stmt->execute(); $res = $stmt->get_result();
$out = []; while ($r = $res->fetch_assoc()) $out[] = $r; $stmt->close();
echo json_encode($out);
