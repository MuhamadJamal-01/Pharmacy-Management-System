<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin','manager']); ensure_real_pharmacy_schema($conn);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
  verify_csrf();
  $id = (int)($_POST['id'] ?? 0);
  $old = get_row_by_id($conn, 'categories', $id);
  if ($old) {
    $stmt = $conn->prepare('UPDATE categories SET deleted_at=NOW() WHERE id=?'); $stmt->bind_param('i',$id); $stmt->execute(); $stmt->close();
    log_audit($conn, 'soft_delete_category', 'categories', $id, $old, null);
  }
  redirect('categories.php');
}
$rows = $conn->query('SELECT * FROM categories WHERE deleted_at IS NULL ORDER BY name');
include 'includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title"><?= t('categories') ?></h1><p class="page-subtitle"><?= t('manage_categories') ?></p></div><div class="actions-row"><a class="btn" href="category_form.php"><span class="material-symbols-outlined">add</span>Add Category</a></div></div>
  <div class="table-card"><div class="table-scroll"><table><thead><tr><th><?= t('name') ?></th><th><?= t('created') ?></th><th><?= t('actions') ?></th></tr></thead><tbody>
    <?php while($r = $rows->fetch_assoc()): ?>
      <tr><td><strong><?= h($r['name']) ?></strong></td><td><?= h($r['created_at']) ?></td><td><div class="toolbar"><a class="btn secondary" href="category_form.php?id=<?= (int)$r['id'] ?>"><?= t('edit') ?></a><form method="POST" style="display:inline" onsubmit="return confirm('Delete this category?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn danger" type="submit"><?= t('delete') ?></button></form></div></td></tr>
    <?php endwhile; ?>
  </tbody></table></div></div>
</div>
<?php include 'includes/footer.php'; ?>
