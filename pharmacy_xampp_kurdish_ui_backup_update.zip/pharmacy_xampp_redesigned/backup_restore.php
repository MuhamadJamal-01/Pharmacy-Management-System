<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin']); ensure_real_pharmacy_schema($conn);
function sql_value($conn, $value) { return $value === null ? 'NULL' : "'" . $conn->real_escape_string($value) . "'"; }
if ($_SERVER['REQUEST_METHOD']==='POST') {
  verify_csrf(); $action=$_POST['action'] ?? '';
  if ($action==='backup') {
    log_audit($conn,'database_backup','database');
    $tables=[]; $res=$conn->query('SHOW TABLES'); while($row=$res->fetch_array()) $tables[]=$row[0];
    $dump="-- PharmaFlow database backup\n-- Created: ".date('Y-m-d H:i:s')."\nSET FOREIGN_KEY_CHECKS=0;\n\n";
    foreach($tables as $table){
      $create=$conn->query('SHOW CREATE TABLE `'.$conn->real_escape_string($table).'`')->fetch_assoc();
      $dump.="DROP TABLE IF EXISTS `{$table}`;\n".$create['Create Table'].";\n\n";
      $rows=$conn->query('SELECT * FROM `'.$conn->real_escape_string($table).'`');
      while($r=$rows->fetch_assoc()){
        $cols=array_map(function($c){ return '`'.str_replace('`','',$c).'`'; }, array_keys($r));
        $vals=array_map(function($v) use ($conn){ return sql_value($conn,$v); }, array_values($r));
        $dump.='INSERT INTO `'.$table.'` ('.implode(',',$cols).') VALUES ('.implode(',',$vals).');' . "\n";
      }
      $dump.="\n";
    }
    $dump.="SET FOREIGN_KEY_CHECKS=1;\n";
    header('Content-Type: application/sql'); header('Content-Disposition: attachment; filename="pharmaflow_backup_'.date('Ymd_His').'.sql"'); echo $dump; exit;
  } elseif ($action==='restore') {
    if (empty($_FILES['sql_file']['tmp_name']) || !is_uploaded_file($_FILES['sql_file']['tmp_name'])) { $message=t('choose_sql_file'); $messageClass='bad'; }
    else {
      $sql=file_get_contents($_FILES['sql_file']['tmp_name']);
      $conn->multi_query($sql);
      while($conn->more_results() && $conn->next_result()) { /* flush */ }
      ensure_real_pharmacy_schema($conn);
      log_audit($conn,'database_restore','database');
      $message=t('restore_completed'); $messageClass='ok';
    }
  }
}
include 'includes/header.php';
?>
<div class="content">
 <div class="page-head"><div><h1 class="page-title"><?= t('backup_restore') ?></h1><p class="page-subtitle"><?= t('backup_restore_subtitle') ?></p></div></div>
 <?php if(!empty($message)): ?><div class="alert <?= h($messageClass) ?>"><?= h($message) ?></div><?php endif; ?>
 <div class="split-grid"><form class="form-card" method="POST"><?= csrf_field() ?><input type="hidden" name="action" value="backup"><h2 class="section-title" style="margin-top:0"><?= t('download_backup') ?></h2><p class="muted"><?= t('backup_sql_help') ?></p><button class="btn" type="submit"><span class="material-symbols-outlined">download</span><?= t('download_sql_backup') ?></button></form>
 <form class="form-card" method="POST" enctype="multipart/form-data" onsubmit="return confirm('<?= t('restore_confirm') ?>')"><?= csrf_field() ?><input type="hidden" name="action" value="restore"><h2 class="section-title" style="margin-top:0"><?= t('restore_backup') ?></h2><p class="muted"><?= t('restore_sql_help') ?></p><input class="input" type="file" name="sql_file" accept=".sql" required><br><br><button class="btn danger" type="submit"><span class="material-symbols-outlined">restore</span><?= t('restore_sql_backup') ?></button></form></div>
</div>
<?php include 'includes/footer.php'; ?>
