<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin','manager','pharmacist']); ensure_real_pharmacy_schema($conn);
$message=''; $messageClass='ok';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  verify_csrf(); $action=$_POST['action'] ?? 'create';
  if ($action === 'create') {
    $patientName=trim($_POST['patient_name'] ?? ''); $phone=trim($_POST['phone'] ?? ''); $doctor=trim($_POST['doctor_name'] ?? ''); $rxNumber=trim($_POST['prescription_number'] ?? ''); $notes=trim($_POST['notes'] ?? '');
    if ($patientName==='') { $message='Patient name is required.'; $messageClass='bad'; }
    else {
      $conn->begin_transaction();
      try {
        $stmt=$conn->prepare('INSERT INTO patients(name,phone,notes) VALUES(?,?,?)'); $stmt->bind_param('sss',$patientName,$phone,$notes); $stmt->execute(); $patientId=$conn->insert_id; $stmt->close();
        $imagePath=null;
        if (!empty($_FILES['prescription_image']['name']) && is_uploaded_file($_FILES['prescription_image']['tmp_name'])) {
          $allowed=['jpg','jpeg','png','pdf']; $ext=strtolower(pathinfo($_FILES['prescription_image']['name'], PATHINFO_EXTENSION));
          if (!in_array($ext,$allowed,true)) throw new RuntimeException('Only JPG, PNG, or PDF prescription files are allowed.');
          if ($_FILES['prescription_image']['size'] > 5*1024*1024) throw new RuntimeException('Prescription file must be 5MB or smaller.');
          $dir=__DIR__.'/storage/prescriptions'; if(!is_dir($dir)) mkdir($dir,0775,true);
          $file='rx_'.date('Ymd_His').'_'.random_int(1000,9999).'.'.$ext; $dest=$dir.'/'.$file;
          if(!move_uploaded_file($_FILES['prescription_image']['tmp_name'],$dest)) throw new RuntimeException('Could not save prescription image.');
          $imagePath='storage/prescriptions/'.$file;
        }
        $createdBy=(int)$_SESSION['user_id'];
        $stmt=$conn->prepare('INSERT INTO prescriptions(patient_id,patient_name,doctor_name,prescription_number,image_path,notes,created_by) VALUES(?,?,?,?,?,?,?)');
        $stmt->bind_param('isssssi',$patientId,$patientName,$doctor,$rxNumber,$imagePath,$notes,$createdBy); $stmt->execute(); $rxId=$conn->insert_id; $stmt->close();
        log_audit($conn,'create_prescription','prescriptions',$rxId,null,get_row_by_id($conn,'prescriptions',$rxId));
        $conn->commit(); $message='Prescription saved and waiting for approval.';
      } catch(Throwable $e){ $conn->rollback(); $message=$e->getMessage(); $messageClass='bad'; }
    }
  } elseif (in_array($action,['approve','reject'],true)) {
    if (!has_role(['admin','pharmacist'])) { http_response_code(403); exit('Only pharmacists/admins can approve prescriptions.'); }
    $id=(int)($_POST['id'] ?? 0); $old=get_row_by_id($conn,'prescriptions',$id); $status=$action==='approve' ? 'approved' : 'rejected'; $uid=(int)$_SESSION['user_id'];
    $stmt=$conn->prepare('UPDATE prescriptions SET status=?, approved_by=?, approved_at=NOW() WHERE id=? AND status IN (\'pending\',\'approved\')');
    $stmt->bind_param('sii',$status,$uid,$id); $stmt->execute(); $stmt->close();
    log_audit($conn,$action.'_prescription','prescriptions',$id,$old,get_row_by_id($conn,'prescriptions',$id));
  }
}
$rows=$conn->query('SELECT p.*, u.name approved_user FROM prescriptions p LEFT JOIN users u ON u.id=p.approved_by ORDER BY p.created_at DESC LIMIT 200');
include 'includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title"><?= t('prescriptions') ?></h1><p class="page-subtitle"><?= t('prescriptions_subtitle') ?></p></div></div>
  <?php if($message): ?><div class="alert <?= h($messageClass) ?>"><?= h($message) ?></div><?php endif; ?>
  <div class="split-grid"><form class="form-card" method="POST" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="action" value="create"><h2 class="section-title" style="margin-top:0"><?= t('new_prescription') ?></h2><div class="form-grid"><div><label>Patient name</label><input class="input" name="patient_name" required></div><div><label>Phone</label><input class="input" name="phone"></div><div><label>Doctor name</label><input class="input" name="doctor_name"></div><div><label>Prescription number</label><input class="input" name="prescription_number"></div><div style="grid-column:1/-1"><label>Upload image/PDF</label><input class="input" type="file" name="prescription_image" accept=".jpg,.jpeg,.png,.pdf"></div><div style="grid-column:1/-1"><label>Notes</label><textarea class="input" name="notes" rows="3"></textarea></div></div><br><button class="btn" type="submit">Save Prescription</button></form><div class="card"><h3>Workflow</h3><p style="font-size:16px;letter-spacing:0">1. Upload prescription proof.<br>2. Pharmacist/admin approves it.<br>3. Cashier selects the approved prescription in POS before selling prescription-required medicines.</p></div></div>
  <br><div class="table-card"><div class="table-header"><h2><?= t('prescription_records') ?></h2></div><div class="table-scroll"><table><thead><tr><th>ID</th><th><?= t('patient') ?></th><th><?= t('doctor') ?></th><th><?= t('number') ?></th><th><?= t('file') ?></th><th><?= t('status') ?></th><th><?= t('approved_by') ?></th><th><?= t('date') ?></th><th><?= t('actions') ?></th></tr></thead><tbody><?php while($r=$rows->fetch_assoc()): $badge=$r['status']==='approved'?'ok':($r['status']==='rejected'?'bad':'warn'); ?><tr><td>#<?= (int)$r['id'] ?></td><td><?= h($r['patient_name']) ?></td><td><?= h($r['doctor_name']) ?></td><td><?= h($r['prescription_number']) ?></td><td><?= $r['image_path'] ? '<a class="btn secondary" target="_blank" href="'.h($r['image_path']).'">Open</a>' : '-' ?></td><td><span class="badge <?= $badge ?>"><?= h($r['status']) ?></span></td><td><?= h($r['approved_user'] ?? '-') ?></td><td><?= h($r['created_at']) ?></td><td><?php if(has_role(['admin','pharmacist']) && in_array($r['status'],['pending','approved'],true)): ?><div class="toolbar"><form method="POST"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="action" value="approve"><button class="btn">Approve</button></form><form method="POST"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="action" value="reject"><button class="btn danger">Reject</button></form></div><?php endif; ?></td></tr><?php endwhile; ?></tbody></table></div></div>
</div>
<?php include 'includes/footer.php'; ?>
