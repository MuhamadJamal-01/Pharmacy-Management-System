
function confirmDelete(){ return confirm('Are you sure?'); }
document.querySelectorAll('.btn,.icon-btn,.medicine-tile').forEach(el=>{
  el.addEventListener('mousedown',()=>el.style.transform='scale(.98)');
  el.addEventListener('mouseup',()=>el.style.transform='');
  el.addEventListener('mouseleave',()=>el.style.transform='');
});

// Theme toggle: toggles 'dark' class on <html> and persists choice
document.addEventListener('DOMContentLoaded', function(){
  const btn = document.getElementById('theme-toggle');
  if(btn) {
    const root = document.documentElement;
    const setTheme = (dark) => {
      root.classList.toggle('dark', !!dark);
      btn.setAttribute('aria-pressed', !!dark);
      btn.title = !!dark ? 'Switch to light mode' : 'Switch to dark mode';
      const icon = btn.querySelector('.material-symbols-outlined');
      if(icon) icon.textContent = !!dark ? 'light_mode' : 'dark_mode';
    };
    // initial state: localStorage -> prefers-color-scheme -> default to light
    let stored = null;
    try { stored = localStorage.getItem('pharma_theme'); } catch(e) { stored = null; }
    if(stored === 'dark') setTheme(true);
    else if(stored === 'light') setTheme(false);
    else setTheme(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);

    btn.addEventListener('click', function(){
      const isDark = document.documentElement.classList.toggle('dark');
      try { localStorage.setItem('pharma_theme', isDark ? 'dark' : 'light'); } catch(e){}
      setTheme(isDark);
    });
  }

  const notifyBtn = document.getElementById('notifications-toggle');
  const notifyPanel = document.getElementById('notifications-panel');
  if(notifyBtn && notifyPanel) {
    const closePanel = () => {
      notifyPanel.hidden = true;
      notifyPanel.classList.remove('is-open');
      notifyBtn.setAttribute('aria-expanded', 'false');
    };
    notifyBtn.addEventListener('click', function(event){
      event.stopPropagation();
      const willOpen = notifyPanel.hidden || !notifyPanel.classList.contains('is-open');
      notifyPanel.hidden = false;
      notifyPanel.classList.toggle('is-open', willOpen);
      if(!willOpen) notifyPanel.hidden = true;
      notifyBtn.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
    });
    notifyPanel.addEventListener('click', event => event.stopPropagation());
    document.addEventListener('click', closePanel);
    document.addEventListener('keydown', function(event){
      if(event.key === 'Escape') closePanel();
    });
  }
});
