// POS cart with barcode search, CSRF protection, payment method, discount and Rx approval support.
document.addEventListener('DOMContentLoaded', function(){
  const search = document.getElementById('pos-search');
  const results = document.getElementById('pos-results');
  const cartList = document.getElementById('pos-cart-items');
  const totalEl = document.getElementById('pos-cart-total');
  const paymentEl = document.getElementById('payment-method');
  const discountEl = document.getElementById('discount-amount');
  const prescriptionEl = document.getElementById('prescription-id');
  let cart = [];

  function money(v){ return Number(v || 0).toLocaleString(undefined, {maximumFractionDigits:0}) + ' IQD'; }
  function escapeHtml(s){ return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

  function renderResults(items){
    results.innerHTML = '';
    if (!items || items.length === 0) { results.textContent = 'No matches'; return; }
    items.forEach(it=>{
      const div = document.createElement('div'); div.className = 'medicine-tile';
      const rx = Number(it.requires_prescription || 0) === 1 ? '<span class="badge warn">Rx required</span>' : '<span class="badge ok">OTC</span>';
      div.innerHTML = `
        <h3>${escapeHtml(it.name)}</h3>
        <p class="muted">${escapeHtml(it.generic_name || '')}</p>
        <div class="stat-line"><span>Stock</span><strong>${Number(it.stock||0)}</strong></div>
        <div class="stat-line"><span>Price</span><strong>${it.price ? money(it.price) : '-'}</strong></div>
        <div style="margin:8px 0">${rx}</div>
        <button class="btn add-to-cart" type="button" data-id="${it.id}" data-name="${escapeHtml(it.name)}" data-price="${it.price || 0}" data-rx="${it.requires_prescription || 0}">Add</button>`;
      results.appendChild(div);
    });
    results.querySelectorAll('.add-to-cart').forEach(btn=>btn.addEventListener('click', function(){
      addToCart({id:this.dataset.id, name:this.dataset.name, price:parseFloat(this.dataset.price||0), qty:1, rx:Number(this.dataset.rx||0)});
    }));
  }
  function addToCart(item){ const existing = cart.find(c=>c.id==item.id); if(existing) existing.qty += item.qty; else cart.push(item); renderCart(); }
  function cartGross(){ return cart.reduce((sum, it)=> sum + (Number(it.price||0) * Number(it.qty||0)), 0); }
  function renderCart(){
    cartList.innerHTML = ''; let total = 0;
    cart.forEach((it,idx)=>{
      const line = Number(it.price||0) * Number(it.qty||0); total += line;
      const div = document.createElement('div'); div.className='stat-line';
      div.innerHTML = `<span>${escapeHtml(it.name)} ${it.rx ? '<span class="badge warn">Rx</span>' : ''} x <input type="number" class="cart-qty" data-idx="${idx}" value="${it.qty}" min="1" style="width:66px"/></span><strong>${money(line)}</strong><button class="btn secondary remove-item" type="button" data-idx="${idx}">Remove</button>`;
      cartList.appendChild(div);
    });
    const discount = Math.max(0, Number(discountEl ? discountEl.value : 0) || 0);
    totalEl.textContent = money(Math.max(0, total - discount));
    cartList.querySelectorAll('.cart-qty').forEach(inp=>inp.addEventListener('change', function(){ const i=parseInt(this.dataset.idx); cart[i].qty = Math.max(1,parseInt(this.value)||1); renderCart(); }));
    cartList.querySelectorAll('.remove-item').forEach(b=>b.addEventListener('click', function(){ cart.splice(parseInt(this.dataset.idx),1); renderCart(); }));
  }
  if(discountEl) discountEl.addEventListener('input', renderCart);
  let timer = null;
  if(search){ search.addEventListener('input', function(){ const v = this.value.trim(); clearTimeout(timer); if(v.length<2){ results.innerHTML=''; return; } timer = setTimeout(()=>{ fetch('search_medicines_ajax.php?q='+encodeURIComponent(v)).then(r=>r.json()).then(renderResults).catch(()=>{results.innerHTML='';}); }, 250); }); }
  const checkoutBtn = document.getElementById('pos-checkout');
  if(checkoutBtn){ checkoutBtn.addEventListener('click', function(){
    if(cart.length===0){ alert('Cart is empty'); return; }
    const payload = {items: cart, csrf_token: checkoutBtn.dataset.csrf, payment_method: paymentEl ? paymentEl.value : 'cash', discount_amount: discountEl ? discountEl.value : 0, prescription_id: prescriptionEl ? prescriptionEl.value : 0};
    fetch('pos.php',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':checkoutBtn.dataset.csrf},body:JSON.stringify(payload)}).then(r=>r.json()).then(data=>{
      if(data.success){ if(confirm('Sale recorded: '+data.invoice+'\nOpen printable receipt?')) window.location.href='sale_view.php?id='+data.sale_id; else window.location.reload(); }
      else { alert('Error: '+(data.error || 'Unknown')); }
    }).catch(()=>alert('Network error'));
  }); }
});
