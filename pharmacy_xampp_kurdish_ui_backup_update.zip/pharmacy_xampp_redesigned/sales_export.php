<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
require_role(['admin','manager','pharmacist','cashier']); ensure_real_pharmacy_schema($conn);

$filename = 'sales_export_' . date('Ymd_His') . '.csv';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$out = fopen('php://output', 'w');
fputcsv($out, ['invoice_number','total_amount','payment_method','discount_amount','status','user','created_at']);
$rows = $conn->query('SELECT s.invoice_number, s.total_amount, s.payment_method, s.discount_amount, s.status, u.name user_name, s.created_at FROM sales s LEFT JOIN users u ON u.id=s.user_id ORDER BY s.created_at DESC');
while ($r = $rows->fetch_assoc()) {
    fputcsv($out, [$r['invoice_number'],$r['total_amount'],$r['payment_method'],$r['discount_amount'],$r['status'],$r['user_name'],$r['created_at']]);
}
fclose($out);
exit;
