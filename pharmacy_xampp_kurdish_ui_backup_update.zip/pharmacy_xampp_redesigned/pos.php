<?php
$input = file_get_contents('php://input');
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin','manager','pharmacist','cashier']); ensure_real_pharmacy_schema($conn);

if ($_SERVER['REQUEST_METHOD']==='POST' && $input) {
  header('Content-Type: application/json; charset=utf-8');
  $data = json_decode($input, true);
  if (!$data || !isset($data['items']) || !is_array($data['items'])) { echo json_encode(['success'=>false,'error'=>'Invalid cart']); exit; }
  if (empty($data['csrf_token']) || !hash_equals(csrf_token(), $data['csrf_token'])) { echo json_encode(['success'=>false,'error'=>'Invalid security token']); exit; }
  $paymentMethod = $data['payment_method'] ?? 'cash';
  if (!in_array($paymentMethod, ['cash','card','debt'], true)) $paymentMethod = 'cash';
  $discount = max(0, (float)($data['discount_amount'] ?? 0));
  $prescriptionId = (int)($data['prescription_id'] ?? 0);
  $conn->begin_transaction();
  try {
    $items = [];
    foreach ($data['items'] as $it) {
      $mid = (int)($it['id'] ?? 0); if ($mid <= 0) continue;
      if (!isset($items[$mid])) $items[$mid] = ['id'=>$mid,'qty'=>0];
      $items[$mid]['qty'] += max(1, (int)($it['qty'] ?? 1));
    }
    if (!$items) throw new RuntimeException('Cart is empty');

    $hasRx = false; $totalAmount = 0.0; $allocations = [];
    foreach ($items as $it) {
      $mid = (int)$it['id']; $qty = max(1,(int)$it['qty']);
      $mstmt = $conn->prepare('SELECT id,name,requires_prescription FROM medicines WHERE id=? AND deleted_at IS NULL LIMIT 1');
      $mstmt->bind_param('i', $mid); $mstmt->execute(); $medicine = $mstmt->get_result()->fetch_assoc(); $mstmt->close();
      if (!$medicine) throw new RuntimeException('Medicine not found');
      if (!empty($medicine['requires_prescription'])) $hasRx = true;
      $stmt = $conn->prepare('SELECT id,quantity,selling_price FROM medicine_batches WHERE medicine_id=? AND deleted_at IS NULL AND expiry_date >= CURDATE() AND quantity>0 ORDER BY expiry_date ASC FOR UPDATE');
      $stmt->bind_param('i',$mid); $stmt->execute(); $res = $stmt->get_result();
      $need = $qty; $used = [];
      while ($need>0 && ($b = $res->fetch_assoc())) { $take = min($need, (int)$b['quantity']); $used[] = ['batch_id'=>(int)$b['id'],'qty'=>$take,'price'=>(float)$b['selling_price']]; $need -= $take; }
      $stmt->close();
      if ($need>0) throw new RuntimeException('Insufficient stock for '.$medicine['name']);
      foreach ($used as $u) { $allocations[] = ['medicine_id'=>$mid,'batch_id'=>$u['batch_id'],'qty'=>$u['qty'],'price'=>$u['price']]; $totalAmount += $u['qty'] * $u['price']; }
    }

    if ($hasRx) {
      if ($prescriptionId <= 0 && has_role(['cashier'])) throw new RuntimeException('Prescription approval is required for one or more medicines. Ask a pharmacist to approve it first.');
      if ($prescriptionId > 0) {
        $pstmt = $conn->prepare("SELECT id,status FROM prescriptions WHERE id=? FOR UPDATE");
        $pstmt->bind_param('i', $prescriptionId); $pstmt->execute(); $rx = $pstmt->get_result()->fetch_assoc(); $pstmt->close();
        if (!$rx || $rx['status'] !== 'approved') throw new RuntimeException('Selected prescription is not approved.');
      }
    }

    $netTotal = max(0, $totalAmount - $discount);
    $invoice = 'INV-'.date('Ymd-His').'-'.random_int(100,999);
    $stmt = $conn->prepare('INSERT INTO sales(invoice_number,total_amount,user_id,payment_method,discount_amount,prescription_id,status) VALUES(?,?,?,?,?,?,\'completed\')');
    $userId = (int)$_SESSION['user_id']; $prescriptionNullable = $prescriptionId ?: null;
    $stmt->bind_param('sdisdi', $invoice, $netTotal, $userId, $paymentMethod, $discount, $prescriptionNullable);
    $stmt->execute(); $sale_id = $conn->insert_id; $stmt->close();
    foreach ($allocations as $a) {
      $lineTotal = $a['qty'] * $a['price'];
      $stmt = $conn->prepare('INSERT INTO sale_items(sale_id,medicine_id,batch_id,quantity,price,total) VALUES(?,?,?,?,?,?)');
      $stmt->bind_param('iiiidd',$sale_id,$a['medicine_id'],$a['batch_id'],$a['qty'],$a['price'],$lineTotal); $stmt->execute(); $stmt->close();
      $stmt = $conn->prepare('UPDATE medicine_batches SET quantity=quantity-? WHERE id=?');
      $stmt->bind_param('ii', $a['qty'], $a['batch_id']); $stmt->execute(); $stmt->close();
      record_stock_movement($conn, $a['medicine_id'], $a['batch_id'], -$a['qty'], 'sale', 'POS sale '.$invoice, 'sales', $sale_id);
    }
    if ($prescriptionId > 0 && $hasRx) {
      $stmt = $conn->prepare("UPDATE prescriptions SET status='used' WHERE id=?"); $stmt->bind_param('i', $prescriptionId); $stmt->execute(); $stmt->close();
    }
    log_audit($conn, 'create_sale', 'sales', $sale_id, null, ['invoice'=>$invoice,'total'=>$netTotal,'payment_method'=>$paymentMethod,'discount'=>$discount]);
    $conn->commit();
    echo json_encode(['success'=>true,'invoice'=>$invoice,'sale_id'=>$sale_id]); exit;
  } catch (Throwable $e) { $conn->rollback(); echo json_encode(['success'=>false,'error'=>$e->getMessage()]); exit; }
}
$prescriptions = approved_prescriptions($conn);
include 'includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title"><?= t('pos') ?></h1><p class="page-subtitle"><?= t('simple_cart') ?></p></div><a class="btn secondary" href="sales.php"><span class="material-symbols-outlined">receipt_long</span><?= t('sales_history') ?></a></div>
  <div class="pos-grid">
    <section>
      <div class="filters"><div class="filter-field"><label><?= t('search') ?></label><input id="pos-search" class="input" placeholder="<?= t('barcode') ?> / <?= t('name') ?>"></div><button class="btn secondary" type="button" onclick="document.getElementById('pos-search').focus()"><span class="material-symbols-outlined">barcode_scanner</span><?= t('barcode') ?></button></div>
      <div id="pos-results" class="medicine-list"></div>
    </section>
    <aside class="card cart-panel">
      <h2><?= t('cart') ?></h2><p class="muted"><?= t('simple_cart') ?></p>
      <div class="filter-field"><label><?= t('payment_method') ?></label><select id="payment-method" class="input"><option value="cash"><?= t('cash') ?></option><option value="card"><?= t('card') ?></option><option value="debt"><?= t('debt_credit') ?></option></select></div>
      <div class="filter-field" style="margin-top:10px"><label><?= t('approved_prescription') ?></label><select id="prescription-id" class="input"><option value="0"><?= t('none') ?></option><?php foreach($prescriptions as $rx): ?><option value="<?= (int)$rx['id'] ?>">#<?= (int)$rx['id'] ?> <?= h($rx['patient_name']) ?> <?= $rx['prescription_number'] ? '('.h($rx['prescription_number']).')' : '' ?></option><?php endforeach; ?></select></div>
      <div class="filter-field" style="margin-top:10px"><label><?= t('discount_iqd') ?></label><input id="discount-amount" class="input" type="number" min="0" step="1" value="0"></div>
      <div class="stat-line"><span><?= t('cashier') ?></span><strong><?= h($_SESSION['user_name'] ?? 'User') ?></strong></div>
      <div class="stat-line"><span><?= t('total') ?></span><strong id="pos-cart-total" class="receipt-total">0 IQD</strong></div>
      <div style="margin-top:12px"><div id="pos-cart-items"></div><button id="pos-checkout" data-csrf="<?= h(csrf_token()) ?>" class="btn" style="width:100%;margin-top:12px"><span class="material-symbols-outlined">shopping_cart_checkout</span><?= t('complete_sale') ?></button></div>
    </aside>
  </div>
</div>
<script src="assets/js/pos.js"></script>
<?php include 'includes/footer.php'; ?>
