<?php
// Shared helpers for PharmaFlow. Keep this file compatible with local XAMPP/mysqli.
if (session_status() === PHP_SESSION_NONE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// Production-safe error handling. Set PHARMAFLOW_DEBUG=1 in the environment to display errors locally.
$debug = getenv('PHARMAFLOW_DEBUG') === '1';
ini_set('display_errors', $debug ? '1' : '0');
ini_set('display_startup_errors', $debug ? '1' : '0');
ini_set('log_errors', '1');
$logDir = __DIR__ . '/../storage/logs';
if (!is_dir($logDir)) { @mkdir($logDir, 0775, true); }
ini_set('error_log', $logDir . '/php_errors.log');
error_reporting(E_ALL);

function current_lang() {
    if (isset($_GET['lang'])) {
        $requested = $_GET['lang'] === 'ku' ? 'ku' : 'en';
        $file = __DIR__ . '/../lang/' . $requested . '.php';
        $_SESSION['lang'] = file_exists($file) ? $requested : 'en';
    }
    return $_SESSION['lang'] ?? 'ku';
}

function t($key) {
    $lang = current_lang();
    $file = __DIR__ . '/../lang/' . $lang . '.php';
    if (!file_exists($file)) $file = __DIR__ . '/../lang/en.php';
    $dict = include $file;
    return is_array($dict) && isset($dict[$key]) ? $dict[$key] : $key;
}

function is_rtl() { return current_lang() === 'ku'; }
function h($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function money($amount) { return number_format((float)$amount, 0) . ' IQD'; }
function redirect($url) { header('Location: ' . $url); exit; }

function csrf_token() {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function csrf_field() { return '<input type="hidden" name="csrf_token" value="' . h(csrf_token()) . '">'; }
function verify_csrf($token = null) {
    $token = $token ?? ($_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    if (!is_string($token) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(419);
        exit(t('csrf_error'));
    }
}

function current_user_role() { return $_SESSION['user_role'] ?? 'guest'; }
function has_role($roles) {
    if (!is_array($roles)) $roles = [$roles];
    return in_array(current_user_role(), $roles, true);
}
function require_login() {
    if (empty($_SESSION['user_id'])) redirect('index.php');
}
function require_role($roles) {
    require_login();
    if (!has_role($roles)) {
        http_response_code(403);
        echo '<!doctype html><html><head><meta charset="utf-8"><title>' . h(t('access_denied')) . '</title><link rel="stylesheet" href="assets/css/style.css"></head><body><div class="content"><div class="alert bad"><strong>' . h(t('access_denied')) . '.</strong> ' . h(t('no_permission')) . '</div><p><a class="btn secondary" href="dashboard.php">' . h(t('back_to_dashboard')) . '</a></p></div></body></html>';
        exit;
    }
}
function can_access($area) {
    $role = current_user_role();
    $map = [
        'dashboard' => ['admin','manager','pharmacist','cashier'],
        'pos' => ['admin','manager','pharmacist','cashier'],
        'medicines' => ['admin','manager','pharmacist'],
        'suppliers' => ['admin','manager'],
        'categories' => ['admin','manager'],
        'sales' => ['admin','manager','pharmacist','cashier'],
        'purchases' => ['admin','manager'],
        'reports' => ['admin','manager','pharmacist'],
        'prescriptions' => ['admin','manager','pharmacist'],
        'stock_adjustments' => ['admin','manager','pharmacist'],
        'users' => ['admin'],
        'backup' => ['admin'],
        'audit' => ['admin','manager'],
        'settings' => ['admin','manager','pharmacist','cashier'],
    ];
    return isset($map[$area]) && in_array($role, $map[$area], true);
}

function db_has_table($conn, $table) {
    // MariaDB/XAMPP can fail when placeholders are used inside SHOW statements.
    // information_schema SELECT queries are safer and portable for prepared statements.
    $stmt = $conn->prepare('SELECT COUNT(*) AS c FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?');
    $stmt->bind_param('s', $table);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return ((int)($row['c'] ?? 0)) > 0;
}
function db_has_column($conn, $table, $column) {
    $stmt = $conn->prepare('SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?');
    $stmt->bind_param('ss', $table, $column);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return ((int)($row['c'] ?? 0)) > 0;
}
function db_add_column_if_missing($conn, $table, $column, $definition) {
    if (!db_has_column($conn, $table, $column)) {
        $conn->query('ALTER TABLE `' . str_replace('`','',$table) . '` ADD COLUMN `' . str_replace('`','',$column) . '` ' . $definition);
    }
}
function db_has_index($conn, $table, $index) {
    $stmt = $conn->prepare('SELECT COUNT(*) AS c FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?');
    $stmt->bind_param('ss', $table, $index);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return ((int)($row['c'] ?? 0)) > 0;
}
function db_add_index_if_missing($conn, $table, $index, $columns, $unique = false) {
    if (!db_has_table($conn, $table) || db_has_index($conn, $table, $index)) return;
    $sql = 'ALTER TABLE `' . str_replace('`','',$table) . '` ADD ' . ($unique ? 'UNIQUE ' : '') . 'INDEX `' . str_replace('`','',$index) . '` (' . $columns . ')';
    try { $conn->query($sql); } catch (Throwable $e) { error_log($e->getMessage()); }
}

function ensure_purchase_tables($conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS purchases (
      id INT AUTO_INCREMENT PRIMARY KEY,
      invoice_number VARCHAR(120) NOT NULL UNIQUE,
      supplier_id INT NULL,
      purchase_date DATE NOT NULL,
      status ENUM('PAID','PARTIAL','UNPAID','RETURNED') DEFAULT 'PAID',
      total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
      user_id INT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $conn->query("CREATE TABLE IF NOT EXISTS purchase_items (
      id INT AUTO_INCREMENT PRIMARY KEY,
      purchase_id INT NOT NULL,
      medicine_id INT NOT NULL,
      batch_id INT NULL,
      quantity INT NOT NULL,
      returned_quantity INT NOT NULL DEFAULT 0,
      purchase_price DECIMAL(12,2) NOT NULL DEFAULT 0,
      selling_price DECIMAL(12,2) NOT NULL DEFAULT 0,
      total DECIMAL(12,2) NOT NULL DEFAULT 0,
      FOREIGN KEY (purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
      FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE,
      FOREIGN KEY (batch_id) REFERENCES medicine_batches(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function ensure_categories_table($conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS categories (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(150) NOT NULL UNIQUE,
      deleted_at DATETIME NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if (!db_has_column($conn, 'categories', 'deleted_at')) db_add_column_if_missing($conn, 'categories', 'deleted_at', 'DATETIME NULL');
    $defaults = ['Antibiotics','Analgesics','Cardiovascular','Allergy','Stomach','Pain Relief','Vitamins','Dermatology','Respiratory'];
    $stmt = $conn->prepare('INSERT IGNORE INTO categories (name) VALUES (?)');
    foreach ($defaults as $name) { $stmt->bind_param('s', $name); $stmt->execute(); }
    $stmt->close();
}

function ensure_real_pharmacy_schema($conn) {
    ensure_categories_table($conn);
    ensure_purchase_tables($conn);

    if (db_has_table($conn, 'users')) {
        db_add_column_if_missing($conn, 'users', 'last_login_at', 'DATETIME NULL');
        db_add_column_if_missing($conn, 'users', 'deleted_at', 'DATETIME NULL');
    }
    if (db_has_table($conn, 'suppliers')) db_add_column_if_missing($conn, 'suppliers', 'deleted_at', 'DATETIME NULL');
    if (db_has_table($conn, 'medicines')) {
        db_add_column_if_missing($conn, 'medicines', 'category_id', 'INT NULL');
        db_add_column_if_missing($conn, 'medicines', 'requires_prescription', 'TINYINT(1) NOT NULL DEFAULT 0');
        db_add_column_if_missing($conn, 'medicines', 'unit_name', "VARCHAR(50) NOT NULL DEFAULT 'unit'");
        db_add_column_if_missing($conn, 'medicines', 'deleted_at', 'DATETIME NULL');
    }
    if (db_has_table($conn, 'medicine_batches')) db_add_column_if_missing($conn, 'medicine_batches', 'deleted_at', 'DATETIME NULL');
    if (db_has_table($conn, 'sales')) {
        db_add_column_if_missing($conn, 'sales', 'patient_id', 'INT NULL');
        db_add_column_if_missing($conn, 'sales', 'prescription_id', 'INT NULL');
        db_add_column_if_missing($conn, 'sales', 'payment_method', "ENUM('cash','card','debt') NOT NULL DEFAULT 'cash'");
        db_add_column_if_missing($conn, 'sales', 'discount_amount', 'DECIMAL(12,2) NOT NULL DEFAULT 0');
        db_add_column_if_missing($conn, 'sales', 'status', "ENUM('completed','refunded','void') NOT NULL DEFAULT 'completed'");
    }
    if (db_has_table($conn, 'sale_items')) db_add_column_if_missing($conn, 'sale_items', 'refunded_quantity', 'INT NOT NULL DEFAULT 0');
    if (db_has_table($conn, 'purchase_items')) db_add_column_if_missing($conn, 'purchase_items', 'returned_quantity', 'INT NOT NULL DEFAULT 0');

    $conn->query("CREATE TABLE IF NOT EXISTS patients (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(180) NOT NULL,
      phone VARCHAR(80),
      notes TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $conn->query("CREATE TABLE IF NOT EXISTS prescriptions (
      id INT AUTO_INCREMENT PRIMARY KEY,
      patient_id INT NULL,
      patient_name VARCHAR(180) NOT NULL,
      doctor_name VARCHAR(180),
      prescription_number VARCHAR(120),
      image_path VARCHAR(255),
      status ENUM('pending','approved','rejected','used') NOT NULL DEFAULT 'pending',
      approved_by INT NULL,
      approved_at DATETIME NULL,
      notes TEXT,
      created_by INT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE SET NULL,
      FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL,
      FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $conn->query("CREATE TABLE IF NOT EXISTS stock_movements (
      id INT AUTO_INCREMENT PRIMARY KEY,
      medicine_id INT NOT NULL,
      batch_id INT NULL,
      quantity_change INT NOT NULL,
      movement_type ENUM('purchase','sale','refund','adjustment','expired_removal','purchase_return','manual_correction') NOT NULL,
      reason VARCHAR(255),
      reference_table VARCHAR(80),
      reference_id INT NULL,
      user_id INT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE,
      FOREIGN KEY (batch_id) REFERENCES medicine_batches(id) ON DELETE SET NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $conn->query("CREATE TABLE IF NOT EXISTS audit_logs (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NULL,
      action VARCHAR(120) NOT NULL,
      table_name VARCHAR(120),
      record_id INT NULL,
      old_value JSON NULL,
      new_value JSON NULL,
      ip_address VARCHAR(64),
      user_agent VARCHAR(255),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $conn->query("CREATE TABLE IF NOT EXISTS stock_adjustments (
      id INT AUTO_INCREMENT PRIMARY KEY,
      medicine_id INT NOT NULL,
      batch_id INT NOT NULL,
      quantity_change INT NOT NULL,
      reason VARCHAR(255) NOT NULL,
      user_id INT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE,
      FOREIGN KEY (batch_id) REFERENCES medicine_batches(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    db_add_index_if_missing($conn, 'medicines', 'idx_medicines_barcode', 'barcode');
    db_add_index_if_missing($conn, 'medicines', 'idx_medicines_category_id', 'category_id');
    db_add_index_if_missing($conn, 'medicine_batches', 'idx_batches_medicine_id', 'medicine_id');
    db_add_index_if_missing($conn, 'medicine_batches', 'idx_batches_expiry_date', 'expiry_date');
    db_add_index_if_missing($conn, 'sales', 'idx_sales_created_at', 'created_at');
    db_add_index_if_missing($conn, 'purchases', 'idx_purchases_created_at', 'created_at');
    db_add_index_if_missing($conn, 'stock_movements', 'idx_stock_movements_medicine_id', 'medicine_id');
    db_add_index_if_missing($conn, 'audit_logs', 'idx_audit_logs_user_id', 'user_id');
    db_add_index_if_missing($conn, 'audit_logs', 'idx_audit_logs_created_at', 'created_at');
}

function log_audit($conn, $action, $table = null, $recordId = null, $oldValue = null, $newValue = null) {
    if (!db_has_table($conn, 'audit_logs')) return;
    try {
        $userId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
        $oldJson = $oldValue === null ? null : json_encode($oldValue, JSON_UNESCAPED_UNICODE);
        $newJson = $newValue === null ? null : json_encode($newValue, JSON_UNESCAPED_UNICODE);
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $agent = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);
        $stmt = $conn->prepare('INSERT INTO audit_logs(user_id,action,table_name,record_id,old_value,new_value,ip_address,user_agent) VALUES(?,?,?,?,?,?,?,?)');
        $stmt->bind_param('ississss', $userId, $action, $table, $recordId, $oldJson, $newJson, $ip, $agent);
        $stmt->execute(); $stmt->close();
    } catch (Throwable $e) { error_log($e->getMessage()); }
}

function record_stock_movement($conn, $medicineId, $batchId, $qtyChange, $type, $reason = '', $referenceTable = null, $referenceId = null) {
    if (!db_has_table($conn, 'stock_movements')) return;
    $userId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
    $stmt = $conn->prepare('INSERT INTO stock_movements(medicine_id,batch_id,quantity_change,movement_type,reason,reference_table,reference_id,user_id) VALUES(?,?,?,?,?,?,?,?)');
    $stmt->bind_param('iiisssii', $medicineId, $batchId, $qtyChange, $type, $reason, $referenceTable, $referenceId, $userId);
    $stmt->execute(); $stmt->close();
}

function get_row_by_id($conn, $table, $id) {
    $table = str_replace('`','',$table);
    $stmt = $conn->prepare('SELECT * FROM `' . $table . '` WHERE id=? LIMIT 1');
    $stmt->bind_param('i', $id); $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
    return $row ?: null;
}

function approved_prescriptions($conn) {
    if (!db_has_table($conn, 'prescriptions')) return [];
    $rows = [];
    $res = $conn->query("SELECT id, patient_name, prescription_number FROM prescriptions WHERE status='approved' ORDER BY created_at DESC LIMIT 200");
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    return $rows;
}
?>
