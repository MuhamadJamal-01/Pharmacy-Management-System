
<?php require_once __DIR__ . '/functions.php';
$current_page = basename($_SERVER['PHP_SELF']);
function nav_active($file) {
    global $current_page;
    return $current_page === $file ? 'active' : '';
}
$user_name = $_SESSION['user_name'] ?? 'Admin User';
$notifications = [];
if (isset($conn) && $conn instanceof mysqli) {
    try {
        $expiredAlerts = $conn->query("SELECT m.id, m.name, b.batch_number, b.expiry_date, b.quantity
            FROM medicine_batches b
            JOIN medicines m ON m.id=b.medicine_id
            WHERE b.quantity > 0 AND m.deleted_at IS NULL AND (b.deleted_at IS NULL) AND b.expiry_date < CURDATE()
            ORDER BY b.expiry_date ASC
            LIMIT 5");
        while ($row = $expiredAlerts->fetch_assoc()) {
            $notifications[] = [
                'type' => 'bad',
                'icon' => 'error',
                'title' => $row['name'],
                'message' => 'Batch ' . $row['batch_number'] . ' expired on ' . $row['expiry_date'] . ' with ' . (int)$row['quantity'] . ' units.',
                'url' => 'medicine_view.php?id=' . (int)$row['id'],
            ];
        }

        $expiringAlerts = $conn->query("SELECT m.id, m.name, b.batch_number, b.expiry_date, b.quantity
            FROM medicine_batches b
            JOIN medicines m ON m.id=b.medicine_id
            WHERE b.quantity > 0 AND m.deleted_at IS NULL AND (b.deleted_at IS NULL) AND b.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
            ORDER BY b.expiry_date ASC
            LIMIT 5");
        while ($row = $expiringAlerts->fetch_assoc()) {
            $notifications[] = [
                'type' => 'warn',
                'icon' => 'schedule',
                'title' => $row['name'],
                'message' => 'Batch ' . $row['batch_number'] . ' expires on ' . $row['expiry_date'] . '.',
                'url' => 'medicine_view.php?id=' . (int)$row['id'],
            ];
        }

        $lowStockAlerts = $conn->query("SELECT m.id, m.name, m.min_stock, COALESCE(SUM(CASE WHEN b.expiry_date >= CURDATE() THEN b.quantity ELSE 0 END),0) stock
            FROM medicines m
            LEFT JOIN medicine_batches b ON b.medicine_id=m.id AND b.deleted_at IS NULL
            WHERE m.deleted_at IS NULL
            GROUP BY m.id
            HAVING stock <= m.min_stock
            ORDER BY stock ASC, m.name ASC
            LIMIT 5");
        while ($row = $lowStockAlerts->fetch_assoc()) {
            $notifications[] = [
                'type' => 'warn',
                'icon' => 'inventory_2',
                'title' => $row['name'],
                'message' => 'Stock is ' . (int)$row['stock'] . '; minimum is ' . (int)$row['min_stock'] . '.',
                'url' => 'medicine_view.php?id=' . (int)$row['id'],
            ];
        }
    } catch (Throwable $e) {
        $notifications[] = [
            'type' => 'bad',
            'icon' => 'warning',
            'title' => 'Notifications unavailable',
            'message' => 'Database alert check failed.',
            'url' => 'dashboard.php',
        ];
    }
}
$notification_count = count($notifications);
?>
<!DOCTYPE html>
<html lang="<?= current_lang() ?>" dir="<?= is_rtl() ? 'rtl' : 'ltr' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= t('app_name') ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600;700&family=Noto+Sans+Arabic:wght@400;500;600;700;800&family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/theme-overrides.css">
</head>
<body class="app-body <?= is_rtl() ? 'rtl' : '' ?>">
<div class="app-shell">
    <aside class="sidebar">
        <a class="brand" href="dashboard.php">
            <span class="brand-icon material-symbols-outlined">medication</span>
            <span>
                <strong>PharmaFlow</strong>
                <small><?= t('clinical_precision') ?></small>
            </span>
        </a>
        <nav class="sidebar-nav">
            <?php if (can_access('dashboard')): ?><a class="<?= nav_active('dashboard.php') ?>" href="dashboard.php"><span class="material-symbols-outlined">dashboard</span><?= t('dashboard') ?></a><?php endif; ?>
            <?php if (can_access('pos')): ?><a class="<?= nav_active('pos.php') ?>" href="pos.php"><span class="material-symbols-outlined">point_of_sale</span><?= t('pos') ?></a><?php endif; ?>
            <?php if (can_access('medicines')): ?><a class="<?= nav_active('medicines.php') || nav_active('medicine_form.php') || nav_active('medicine_view.php') ? 'active' : '' ?>" href="medicines.php"><span class="material-symbols-outlined">medication</span><?= t('medicines') ?></a><?php endif; ?>
            <?php if (can_access('prescriptions')): ?><a class="<?= nav_active('prescriptions.php') ?>" href="prescriptions.php"><span class="material-symbols-outlined">clinical_notes</span><?= t('prescriptions') ?></a><?php endif; ?>
            <?php if (can_access('suppliers')): ?><a class="<?= nav_active('suppliers.php') ?>" href="suppliers.php"><span class="material-symbols-outlined">local_shipping</span><?= t('suppliers') ?></a><?php endif; ?>
            <?php if (can_access('categories')): ?><a class="<?= nav_active('categories.php') ?>" href="categories.php"><span class="material-symbols-outlined">category</span><?= t('categories') ?></a><?php endif; ?>
            <?php if (can_access('sales')): ?><a class="<?= nav_active('sales.php') || nav_active('sale_view.php') ? 'active' : '' ?>" href="sales.php"><span class="material-symbols-outlined">receipt_long</span><?= t('sales') ?></a><?php endif; ?>
            <?php if (can_access('purchases')): ?><a class="<?= nav_active('purchases.php') || nav_active('purchase_form.php') ? 'active' : '' ?>" href="purchases.php"><span class="material-symbols-outlined">shopping_cart</span><?= t('purchases') ?></a><?php endif; ?>
            <?php if (can_access('stock_adjustments')): ?><a class="<?= nav_active('stock_adjustments.php') ?>" href="stock_adjustments.php"><span class="material-symbols-outlined">tune</span><?= t('stock_adjustments') ?></a><?php endif; ?>
            <?php if (can_access('reports')): ?><a class="<?= nav_active('reports.php') ?>" href="reports.php"><span class="material-symbols-outlined">assessment</span><?= t('reports') ?></a><?php endif; ?>
            <?php if (can_access('users')): ?><a class="<?= nav_active('users.php') ?>" href="users.php"><span class="material-symbols-outlined">manage_accounts</span><?= t('users') ?></a><?php endif; ?>
            <?php if (can_access('backup')): ?><a class="<?= nav_active('backup_restore.php') ?>" href="backup_restore.php"><span class="material-symbols-outlined">backup</span><?= t('backup') ?></a><?php endif; ?>
            <?php if (can_access('audit')): ?><a class="<?= nav_active('audit_logs.php') ?>" href="audit_logs.php"><span class="material-symbols-outlined">policy</span><?= t('audit_logs') ?></a><?php endif; ?>
            <?php if (can_access('settings')): ?><a class="<?= nav_active('settings.php') ?>" href="settings.php"><span class="material-symbols-outlined">settings</span><?= t('settings') ?></a><?php endif; ?>
        </nav>
        <div class="sidebar-footer">
            <a href="logout.php"><span class="material-symbols-outlined">logout</span><?= t('logout') ?></a>
        </div>
    </aside>

    <main class="main">
        <header class="topbar">
            <form class="global-search" action="search.php" method="GET">
                <span class="material-symbols-outlined">search</span>
                <input name="q" type="text" placeholder="<?= t('global_search') ?>" value="<?= h($_GET['q'] ?? '') ?>">
            </form>
            <div class="top-actions">
                <a class="language-pill" href="?lang=en">EN</a>
                <a class="language-pill" href="?lang=ku">کوردی</a>
                <button id="theme-toggle" class="icon-btn" type="button" aria-pressed="false" title="<?= t('toggle_theme') ?>"><span class="material-symbols-outlined">dark_mode</span></button>
                <div class="notification-wrap">
                    <button id="notifications-toggle" class="icon-btn <?= $notification_count ? 'has-dot' : '' ?>" type="button" aria-expanded="false" aria-controls="notifications-panel" title="Notifications">
                        <span class="material-symbols-outlined">notifications</span>
                        <?php if ($notification_count): ?><span class="notification-count"><?= $notification_count > 9 ? '9+' : (int)$notification_count ?></span><?php endif; ?>
                    </button>
                    <div id="notifications-panel" class="notifications-panel" hidden>
                        <div class="notifications-head">
                            <strong><?= t('notifications') ?></strong>
                            <span><?= (int)$notification_count ?></span>
                        </div>
                        <?php if ($notification_count): ?>
                            <div class="notifications-list">
                                <?php foreach ($notifications as $note): ?>
                                    <a class="notification-item <?= h($note['type']) ?>" href="<?= h($note['url']) ?>">
                                        <span class="material-symbols-outlined"><?= h($note['icon']) ?></span>
                                        <span>
                                            <strong><?= h($note['title']) ?></strong>
                                            <small><?= h($note['message']) ?></small>
                                        </span>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                            <a class="notifications-footer" href="reports.php"><?= t('reports') ?></a>
                        <?php else: ?>
                            <div class="notification-empty">
                                <span class="material-symbols-outlined">check_circle</span>
                                <strong><?= t('no_active_alerts') ?></strong>
                                <small><?= t('stock_expiry_clear') ?></small>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="profile-chip">
                    <span class="avatar"><?= strtoupper(substr($user_name, 0, 1)) ?></span>
                    <span><?= h($user_name) ?><small style="display:block;color:var(--muted);font-size:11px;text-transform:uppercase"><?= h(current_user_role()) ?></small></span>
                </div>
            </div>
        </header>
