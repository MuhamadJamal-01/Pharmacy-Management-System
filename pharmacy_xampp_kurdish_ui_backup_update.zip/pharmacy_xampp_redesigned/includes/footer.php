
    </main>
</div>
<nav class="mobile-nav">
    <a href="dashboard.php"><span class="material-symbols-outlined">dashboard</span><small><?= t('dashboard') ?></small></a>
    <a href="pos.php"><span class="material-symbols-outlined">point_of_sale</span><small><?= t('pos') ?></small></a>
    <a href="medicines.php"><span class="material-symbols-outlined">medication</span><small><?= t('medicines') ?></small></a>
    <a href="sales.php"><span class="material-symbols-outlined">receipt_long</span><small><?= t('sales') ?></small></a>
</nav>
<script src="assets/js/app.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function(){
    const ctx = document.getElementById('stockTrendChart');
    if(!ctx) return;
    const labels = <?= json_encode($labels ?? []) ?>;
    const inbound = <?= json_encode($inboundData ?? []) ?>;
    const dispensed = <?= json_encode($dispensedData ?? []) ?>;
    new Chart(ctx.getContext('2d'), {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                { label: 'Inbound', data: inbound, borderColor: '#16a34a', backgroundColor: 'rgba(16,163,74,0.08)', tension:0.3, pointRadius:3 },
                { label: 'Dispensed', data: dispensed, borderColor: '#d97706', backgroundColor: 'rgba(217,119,6,0.08)', tension:0.3, pointRadius:3 }
            ]
        },
        options: { responsive:true, maintainAspectRatio:false, plugins:{legend:{position:'top'}}, scales:{y:{beginAtZero:true}} }
    });
});
</script>
</body>
</html>
