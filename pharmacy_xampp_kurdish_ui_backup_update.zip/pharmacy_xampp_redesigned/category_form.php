<?php
require_once 'config/db.php'; require_once 'includes/functions.php'; require_role(['admin','manager']); ensure_real_pharmacy_schema($conn);
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$name = ''; $error = '';
if ($id) {
  $stmt = $conn->prepare('SELECT id,name FROM categories WHERE id=? AND deleted_at IS NULL'); $stmt->bind_param('i',$id); $stmt->execute(); $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
  if ($row) $name = $row['name']; else redirect('categories.php');
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
  verify_csrf();
  $name = trim($_POST['name'] ?? '');
  if ($name === '') $error = t('category_name_required');
  else {
    try {
      if ($id) {
        $old = get_row_by_id($conn, 'categories', $id);
        $stmt = $conn->prepare('UPDATE categories SET name=? WHERE id=?'); $stmt->bind_param('si',$name,$id); $stmt->execute(); $stmt->close();
        log_audit($conn, 'update_category', 'categories', $id, $old, get_row_by_id($conn, 'categories', $id));
      } else {
        $stmt = $conn->prepare('INSERT INTO categories (name) VALUES (?)'); $stmt->bind_param('s',$name); $stmt->execute(); $id=$conn->insert_id; $stmt->close();
        log_audit($conn, 'create_category', 'categories', $id, null, get_row_by_id($conn, 'categories', $id));
      }
      redirect('categories.php');
    } catch (mysqli_sql_exception $e) { $error = t('category_exists'); }
  }
}
include 'includes/header.php';
?>
<div class="content">
  <div class="page-head"><div><h1 class="page-title"><?= $id ? 'Edit Category' : 'Add Category' ?></h1></div></div>
  <?php if($error): ?><div class="alert bad"><?= h($error) ?></div><?php endif; ?>
  <form class="form-card" method="POST"><?= csrf_field() ?><div class="form-grid"><div><label><?= t('name') ?></label><input class="input" name="name" required value="<?= h($name) ?>"></div></div><br><button class="btn" type="submit"><?= t('save') ?></button></form>
</div>
<?php include 'includes/footer.php'; ?>
